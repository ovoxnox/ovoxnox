#!/usr/bin/env python
"""convert_semgrep.py -- convert semgrep-rules YAML corpora to pegrex catalogs.

Usage: python tools/convert_semgrep.py <extracted-corpus-dir>

Merges into pegrex/secrules.json (patterns) and pegrex/secrules_taint.json
(taint), deduped by rule id.  Guards: qualified/bare callees, empty
alternations dropped, degenerate regexes skipped.
"""
import json
import pathlib
import re
import sys

import yaml

ROOT = pathlib.Path(__file__).resolve().parent.parent
TARGET = {"python", "go", "rust", "javascript", "typescript", "js", "ts",
          "java", "kotlin", "kt", "solidity", "c", "cpp", "xml", "swift"}
SEV = {"ERROR": "HIGH", "WARNING": "MEDIUM", "INFO": "LOW"}
CALL_RE = re.compile(r"^\s*(?:[\w\[\]'\"]+\s*=\s*)?([\w.]+)\s*(?:\.\.\.\s*)?\(")


def extract_strings(node, key, out):
    if isinstance(node, dict):
        for k, v in node.items():
            if k == key and isinstance(v, str):
                out.append(v)
            else:
                extract_strings(v, key, out)
    elif isinstance(node, list):
        for v in node:
            extract_strings(v, key, out)


def ok(rx):
    try:
        re.compile(rx)
        return True
    except re.error:
        return False


def qualify(c):
    return r"\.\s*".join(re.escape(p) for p in c.split("."))


def convert(src_dir):
    patterns, taint = [], []
    for y in pathlib.Path(src_dir).rglob("*.y*ml"):
        try:
            doc = yaml.safe_load(y.read_text())
        except Exception:
            continue
        for rule in (doc or {}).get("rules", []):
            langs = rule.get("languages", [])
            if not (set(langs) & TARGET):
                continue
            rid = rule.get("id", y.stem)
            sev = SEV.get(rule.get("severity", "WARNING"), "MEDIUM")
            msg = rule.get("message", "")
            if rule.get("mode") == "taint" or "pattern-sinks" in rule:
                sinks, sources, sanit = [], [], []
                for k, d in (("pattern-sinks", sinks), ("pattern-sources", sources),
                             ("pattern-sanitizers", sanit)):
                    extract_strings(rule.get(k), "pattern", d)

                def sigs(ps):
                    out = []
                    for p in ps:
                        m = CALL_RE.match(p.replace("$", ""))
                        if m:
                            c = m.group(1)
                            body = qualify(c) if "." in c else re.escape(c)
                            out.append(body + r"\s*\(")
                    return [s for s in out if ok(s)]
                s_, so_, sa_ = sigs(sinks), sigs(sources), sigs(sanit)
                if s_ and so_:
                    taint.append({"id": rid, "langs": langs, "severity": sev,
                                  "message": msg[:140], "sinks": s_,
                                  "sources": so_, "sanitizers": sa_})
                continue
            pats, regexes, mv = [], [], []
            for k in ("pattern", "patterns"):
                extract_strings(rule.get(k), "pattern", pats)
                extract_strings(rule.get(k), "pattern-regex", regexes)
                extract_strings(rule.get(k), "metavariable-regex", mv)
            entry = None
            callees = set()
            for p in pats:
                m = CALL_RE.match(p.replace("$", ""))
                if m:
                    callees.add(m.group(1))
            qual = sorted({qualify(c) for c in callees if "." in c})
            bare = sorted({re.escape(c) for c in callees
                           if "." not in c and len(c) >= 3})[:6]
            parts = qual + [r"(?<![\w.])" + b for b in bare]
            if parts:
                rx = r"(?:%s)\s*\(" % "|".join(parts)
                if "(?:)" not in rx and ok(rx):
                    entry = {"kind": "call", "node_type": "call",
                             "text": rx, "confidence":
                             "high" if qual and not bare else "medium"}
            if entry is None and regexes:
                good = [r for r in regexes if ok(r) and len(r) >= 10
                        and r not in (".*", ".+")]
                if good:
                    entry = {"kind": "file", "text": good[0],
                             "confidence": "medium"}
            if entry is None and mv and pats:
                good = [r for r in mv if ok(r) and len(r) >= 6]
                if good:
                    entry = {"kind": "call", "node_type": "call",
                             "text": good[0], "confidence": "medium"}
            if entry:
                patterns.append({"id": rid, "langs": langs, "severity": sev,
                                 "message": msg[:140], "match": entry})
    return patterns, taint


def main(argv):
    src = argv[1]
    patterns, taint = convert(src)
    cat = json.loads((ROOT / "pegrex/secrules.json").read_text())
    have = {r["id"] for r in cat["rules"]}
    added = [r for r in patterns if r["id"] not in have]
    cat["rules"] += added
    (ROOT / "pegrex/secrules.json").write_text(json.dumps(cat, indent=1))
    tc = json.loads((ROOT / "pegrex/secrules_taint.json").read_text())
    havet = {r["id"] for r in tc["rules"]}
    addedt = [r for r in taint if r["id"] not in havet]
    tc["rules"] += addedt
    (ROOT / "pegrex/secrules_taint.json").write_text(json.dumps(tc, indent=1))
    print(f"patterns: +{len(added)} (reject {len(patterns) - len(added)} dups) "
          f"-> {len(cat['rules'])} total")
    print(f"taint:    +{len(addedt)} (reject {len(taint) - len(addedt)} dups) "
          f"-> {len(tc['rules'])} total")


if __name__ == "__main__":
    main(sys.argv)
