"""
╔══════════════════════════════════════════════════════════════════════════╗
║  a p i                                                                    ║
║  The unified engine API: every achieved feature as one import.           ║
║                                                                          ║
║    from pegrex import api                                                ║
║    api.audit("app.py")                      # security findings          ║
║    api.contracts("fact.py")                 # (constraints -> result)    ║
║    api.spec("src.py", "name")               # AI spec schema             ║
║    api.gaps("src.py", lcov)                 # constraint-aware gaps      ║
║    api.synthesize_tests(...)                # gap -> concrete tests      ║
║    api.compose / api.expand_calls           # modular contracts          ║
║    api.bisimilar(a_cfg, b_cfg, ...)         # bound-free equivalence     ║
║    api.induce(pos, neg, seed)               # grammar induction          ║
║    api.rag_index(dir) / api.rag_search(...) # retrieval                  ║
║    api.budget_check("f.py", max_loc=300)    # complexity gate            ║
║    api.races(src)                           # OpenMP/PyOMP races         ║
║    api.recursion_report(name, body, src)    # bounded/unbounded          ║
║    api.mir_cfg(mir_text)                    # rustc MIR -> CFG           ║
║    api.repo_index(dir) / api.bundle(src)    # repo artifacts             ║
║    api.AcpServer                            # ACP server (tools API)     ║
╚══════════════════════════════════════════════════════════════════════════╝
"""
from __future__ import annotations

import pathlib

from . import cache, contract, coverage, extension, workflow  # noqa: F401
from .budget import Budget
from .callgraph import CallGraph
from .callgraph import build_call_graph as _build_call_graph                                     # noqa: F401
from .bisim import bisimilar                                   # noqa: F401
from .cfg import CFG, CFGBuilder, TagSpec                      # noqa: F401
from .coverage import coverage_gaps, parse_gocover, parse_lcov  # noqa: F401
from .gramir import lift, lift_grammar, lower, to_dsl          # noqa: F401
from .induce import fitness, induce, mutate                    # noqa: F401
from .mini_llm import NGramLM                                  # noqa: F401
from .parallel import find_pragmas, race_findings              # noqa: F401
from .paths import PathEnumerator, PathFormula, linearize      # noqa: F401
from .patterns import Pattern, match, scan                     # noqa: F401
from .recursion import analyze_recursion                       # noqa: F401
from .smt import Backend, auto_feasible, entails, learn  # noqa: F401
from .summaries import compose, expand_calls, path_summaries   # noqa: F401
from .sym import *                                             # noqa: F401,F403
from .testsynth import SynthesizedTest, synthesize_tests       # noqa: F401
from .tokenizer import Token, token_stream, tokenize           # noqa: F401

ROOT = pathlib.Path(__file__).resolve().parent.parent


def audit(path: str, lang: str | None = None) -> list[dict]:
    """Security audit: pattern rules + taint + SCA -> findings."""
    sys_path = __import__("sys").path
    if str(ROOT) not in sys_path:
        sys_path.insert(0, str(ROOT))
    from tools.secaudit import audit as _audit
    return _audit(path, lang)


def spec(source: str, name: str, out_dir: str = "specs",
         views=None, analyzers=None) -> dict:
    """Multi-view AI spec schema -> dict (also written to out_dir)."""
    import json as _json
    import sys as _sys
    if str(ROOT) not in _sys.path:
        _sys.path.insert(0, str(ROOT))
    from tools.mkspec import core as mkspec
    ctx, facts = mkspec.run_analyzers(source, analyzers)
    results = mkspec.run_opus(ctx, facts, views)
    rendered = mkspec.render_spec(ctx, facts, results, "full", name)
    out = pathlib.Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / f"{name}.spec.json").write_text(_json.dumps(rendered, indent=1))
    return rendered


def contracts(path: str, lang: str = "python") -> list:
    """Function contract: [(constraints, result)] per path."""
    import pipeline  # frontends live in the ops layer
    src = pathlib.Path(path).read_text()
    parse, tags, mk = pipeline.FRONTENDS[lang]()
    body = parse(src)
    cfg = CFGBuilder(tags).build(body)
    render = lambda st: (src[st.pos:st.endpos]).replace("return", "").strip() \
        if lang == "python" else None
    return path_summaries(cfg, mk(src), render)


def coverage(path: str, lcov_path: str, lang: str = "python") -> dict:
    """Coverage overlay + gaps: path_coverage per path, gaps with constraints."""
    import pipeline
    from .coverage import (covered_lines, parse_lcov, path_coverage,
                           coverage_gaps)
    src = pathlib.Path(path).read_text()
    cov = list(parse_lcov(pathlib.Path(lcov_path).read_text()).values())
    cov_lines = covered_lines(cov[0]) if cov else set()
    parse, tags, mk = pipeline.FRONTENDS[lang]()
    cfg = CFGBuilder(tags).build(parse(src))
    paths = PathEnumerator(cfg, unroll=2).enumerate()
    return {"paths": path_coverage(cfg, paths, cov_lines),
            "gaps": coverage_gaps(cfg, mk(src), cov_lines)}


def gaps(source: str, lcov: str, lang: str = "python") -> list[dict]:
    """Coverage gaps with constraint context."""
    import pipeline
    src = pathlib.Path(source).read_text()
    cov = list(parse_lcov(pathlib.Path(lcov).read_text()).values())
    cov_lines = __import__("pegrex.coverage", fromlist=["covered_lines"]
                           ).covered_lines(cov[0]) if cov else set()
    parse, tags, mk = pipeline.FRONTENDS[lang]()
    cfg = CFGBuilder(tags).build(parse(src))
    return coverage_gaps(cfg, mk(src), cov_lines)


def synthesize(source: str, lcov: str, fn_name: str | None = None) -> list:
    """Synthesize pytest tests from coverage gaps."""
    from .coverage import covered_lines
    import pipeline
    src = pathlib.Path(source).read_text()
    cov = list(parse_lcov(pathlib.Path(lcov).read_text()).values())
    cov_lines = covered_lines(cov[0]) if cov else set()
    parse, tags, mk = pipeline.python_frontend()
    cfg = CFGBuilder(tags).build(parse(src))
    return synthesize_tests(cfg, mk(src), cov_lines,
                            fn_name or pathlib.Path(source).stem[:-3])


def call_graph(source: str, lang: str = "python") -> "CallGraph":
    """Function-call graph: nodes are functions, edges caller -> callee,
    with DOT + ASCII visualizations (m50)."""
    return _build_call_graph(source, lang)


def rag_index(paths) -> "object":
    from .rag import build_index
    return build_index(paths)


def rag_search(index, query: str, k: int = 5) -> list:
    from .rag import retrieve
    return retrieve(index, query, k)


def budget_check(path: str, max_loc: int = 300,
                 max_function_lines: int = 40) -> Budget:
    b = Budget(max_loc=max_loc, max_function_lines=max_function_lines)
    return b.check(path, pathlib.Path(path).read_text())


def races(src: str) -> list[str]:
    return race_findings(src)


def recursion_report(fn_name: str, body, src: str):
    return analyze_recursion(fn_name, body, src)


def mir_cfg(mir_text: str) -> CFG:
    import sys as _sys
    if str(ROOT) not in _sys.path:
        _sys.path.insert(0, str(ROOT))
    import pipeline
    _, cfg_from_mir, _ = pipeline.mir_frontend()
    return cfg_from_mir(mir_text)


def repo_index(root: str, out: str = "repo.index.json") -> dict:
    import sys as _sys
    if str(ROOT) not in _sys.path:
        _sys.path.insert(0, str(ROOT))
    from tools.repokit import repo_index as _ri
    return _ri(root, out=out)


def bundle(source: str, out: str | None = None) -> dict:
    import sys as _sys
    if str(ROOT) not in _sys.path:
        _sys.path.insert(0, str(ROOT))
    from tools.repokit import verification_bundle
    return verification_bundle(source, out=out)


from .acp import AcpServer                                     # noqa: E402,F401

from .circuit import check_circuit                                # noqa: E402
from .egraphs import EGraph                                       # noqa: E402
from .formalize import check_invariant as spec_check, formalize   # noqa: E402
from .legal import obligations_as_constraints, parse_clauses      # noqa: E402
from .metaengine import build_system                              # noqa: E402
from .modelcheck import check_invariant                           # noqa: E402
from .ownership import borrow_check                               # noqa: E402
from .passverify import verify_pass                               # noqa: E402
from .poc import codegen_gate, poc_template                       # noqa: E402
from .protocol import verify_protocol                             # noqa: E402
from .proofrepair import ast_fingerprint, diff_blocks             # noqa: E402
from .synthesize import synthesize                                # noqa: E402
from .transpiler import transpile                                 # noqa: E402
from .wp import wp_assign, wp_cond, wp_path                       # noqa: E402
from .abstract import interval_analysis                           # noqa: E402

from .mcp import MCPRouter, MCPServer, engine_tools                # noqa: E402

from .ci import analyze_pipeline as ci_scan                       # noqa: E402
from .sca import scan as osv_scan                                # noqa: E402
from .export import export as export_findings                    # noqa: E402
from .transpiler import transpile                                # noqa: E402
