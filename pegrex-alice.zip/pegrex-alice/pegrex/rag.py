"""
╔══════════════════════════════════════════════════════════════════════════╗
║  r a g                                                                    ║
║  Retrieval-augmented generation: chunk sources -> tokenized inverted     ║
║  index -> retrieve(query, k) by token-kind overlap.  Feeds the ACP       ║
║  server with grounded context (no external vector DB).                   ║
╚══════════════════════════════════════════════════════════════════════════╝
"""
from __future__ import annotations

import math
import pathlib
from collections import Counter
from dataclasses import dataclass, field

from .tokenizer import tokenize


@dataclass
class Chunk:
    source: str
    start_line: int
    text: str
    tokens: list = field(default_factory=list)


@dataclass
class Index:
    chunks: list = field(default_factory=list)
    inverted: dict = field(default_factory=dict)   # token -> set(chunk_idx)
    doc_len: list = field(default_factory=list)


def chunk_source(path: str, src: str, max_lines: int = 40) -> list[Chunk]:
    """Function-aware chunking (tree-sitter when available) else line windows."""
    chunks = []
    try:
        import pipeline
        parse, _, _ = pipeline.python_frontend()
        body = parse(src)
        lines = src.splitlines()
        for b in getattr(body, "children", []):
            if getattr(b, "tag", "") in ("function_definition", "async_function_definition"):
                start = src[:b.pos].count("\n") + 1
                end = src[:b.endpos].count("\n") + 1
                text = "\n".join(lines[start - 1:end])
                chunks.append(Chunk(path, start, text, []))
    except Exception:
        pass
    if not chunks:
        lines = src.splitlines()
        for i in range(0, len(lines), max_lines):
            chunks.append(Chunk(path, i + 1,
                                "\n".join(lines[i:i + max_lines]), []))
    for c in chunks:
        c.tokens = [(t.kind, t.value) for t in tokenize(c.text)]
    return chunks


def build_index(paths) -> Index:
    idx = Index()
    for p in paths:
        p = pathlib.Path(p)
        if p.is_dir():
            for f in sorted(p.rglob("*.py")):
                if "__pycache__" not in str(f) and ".vendor" not in str(f):
                    idx.chunks += chunk_source(str(f), f.read_text())
        elif p.exists():
            idx.chunks += chunk_source(str(p), p.read_text())
    for i, c in enumerate(idx.chunks):
        for tok in set(c.tokens):
            idx.inverted.setdefault(tok, set()).add(i)
    idx.doc_len = [len(c.tokens) for c in idx.chunks]
    return idx


def retrieve(idx: Index, query: str, k: int = 5) -> list[Chunk]:
    """BM25-lite over token (kind, value) overlap."""
    qtokens = [(t.kind, t.value) for t in tokenize(query)]
    scores = Counter()
    n = len(idx.chunks)
    avgdl = sum(idx.doc_len) / max(n, 1)
    for tok in qtokens:
        postings = idx.inverted.get(tok)
        if not postings:
            continue
        df = len(postings)
        idf = math.log(1 + (n - df + 0.5) / (df + 0.5))
        for ci in postings:
            tf = idx.chunks[ci].tokens.count(tok)
            dl = idx.doc_len[ci]
            scores[ci] += idf * tf * 1.2 / (tf + 1.2 * (1 - 0.75 + 0.75 * dl / max(avgdl, 1)))
    return [idx.chunks[i] for i, _ in scores.most_common(k)]
