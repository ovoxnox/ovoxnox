"""
╔══════════════════════════════════════════════════════════════════════════╗
║  p e g r e x   C L I                                                      ║
║  The complete command-line interface (argparse subcommands).             ║
║  Every engine capability, one entry point: `pegrex <command> -h`.        ║
╚══════════════════════════════════════════════════════════════════════════╝
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

__version__ = "1.0.0"


def _expand(path: str, suffixes=(".py",)) -> list:
    """Expand a file or directory (recursive) to matching source files."""
    p = pathlib.Path(path)
    if p.is_dir():
        return sorted(f for f in p.rglob("*") if f.suffix in suffixes
                      and "__pycache__" not in str(f) and ".vendor" not in str(f))
    return [p]


def _cmd_audit(a) -> int:
    from tools.secaudit import audit
    findings = audit(a.file, a.lang)
    import json as _json, pathlib as _pl, datetime
    log = _pl.Path(".pegrex-cache/audit.log")
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open("a") as fh:
        fh.write(_json.dumps({"ts": datetime.datetime.now().isoformat(
            timespec="seconds"), "file": a.file,
            "findings": len(findings)}) + chr(10))
    if a.json:
        print(json.dumps({"file": a.file, "findings": findings,
                          "total": len(findings)}, indent=1))
    else:
        for f in findings:
            print(f"{f['severity']:9} {f.get('confidence', ''):7} "
                  f"{f['id']:44} L{f['line']:<4} {f['evidence']}")
        print()
        print(f"total: {len(findings)} findings")
    return 0


def _cmd_spec(a) -> int:
    from pegrex import api
    if a.dir:
        for f in _expand(a.dir if isinstance(a.dir, str) else (a.source or ".")):
            spec = api.spec(str(f), f"{a.name}_{f.stem}", out_dir=a.out,
                            views=a.opus, analyzers=a.analyzers)
            print(f"  {f.name}: {len(spec['tasks'])} tasks")
        return 0
    spec = api.spec(a.source, a.name, out_dir=a.out, views=a.opus,
                    analyzers=a.analyzers)
    print(f"wrote {a.out}/{a.name}.spec.json "
          f"({len(spec['tasks'])} tasks, "
          f"{spec['meta']['finding_count']} findings)")
    return 0


def _cmd_contracts(a) -> int:
    from pegrex import api
    for cons, res in api.contracts(a.file, a.lang):
        print(f"  {sorted(cons)} -> {res}")
    return 0


def _cmd_callgraph(a) -> int:
    from pegrex.callgraph import CallGraph, build_call_graph
    target = a.dir if isinstance(a.dir, str) else (a.file or ".")
    if a.dir:
        g = CallGraph()
        for f in _expand(target):
            sub = build_call_graph(f.read_text(), a.lang)
            g.functions.update({f"{f.stem}.{k}": v
                                for k, v in sub.functions.items()})
            g.edges |= {(f"{f.stem}.{c}", f"{f.stem}.{d}")
                        for c, d in sub.edges}
    else:
        g = build_call_graph(pathlib.Path(a.file).read_text(), a.lang)
    print(g.to_ascii() if a.ascii else g.to_dot())
    return 0


def _cmd_coverage(a) -> int:
    from pegrex import api
    if a.dir:
        rc = 0
        for f in _expand(a.dir if isinstance(a.dir, str) else (a.source or ".")):
            out = api.coverage(str(f), a.lcov, a.lang)
            gaps = [g for g in out["gaps"]]
            print(f"{f}: {len(out['paths'])} paths, {len(gaps)} gap(s)")
            rc |= bool(gaps)
        return rc
    out = api.coverage(a.source, a.lcov, a.lang)
    for p in out["paths"]:
        mark = "COVERED" if p["covered"] else "gap"
        print(f"  {mark:8} {p['blocks']}")
    for g in out["gaps"]:
        print(f"  gap: {sorted(set(g['constraints']))}")
    return 0


def _cmd_gaps(a) -> int:
    from pegrex import api
    for g in api.gaps(a.source, a.lcov, a.lang):
        print(f"  {sorted(set(g['constraints']))}")
    return 0


def _cmd_tests(a) -> int:
    from pegrex import api
    for t in api.synthesize(a.source, a.lcov):
        print(t.test_body)
        print()
    return 0


def _cmd_budget(a) -> int:
    from pegrex.budget import Budget
    _t = a.dir if isinstance(a.dir, str) else (a.file or ".")
    files = _expand(_t) if a.dir else [pathlib.Path(a.file)]
    all_findings, failed = [], False
    for f in files:
        b = Budget(max_loc=a.max_loc,
                   max_function_lines=a.max_function_lines)
        b.check(str(f), f.read_text())
        all_findings += b.findings
        failed |= not b.passed
        if b.findings:
            print(f"{f}:")
            for x in b.findings:
                print("  ", x)
    print(f"gate: {'FAIL' if failed else 'PASS'} "
          f"({len(files)} files, {len(all_findings)} findings)")
    return 1 if failed else 0


def _cmd_index(a) -> int:
    from pegrex import api
    idx = api.repo_index(a.dir, out=a.out)
    print(f"wrote {a.out}: {len(idx['containers'])} containers")
    return 0


def _cmd_bundle(a) -> int:
    from pegrex import api
    if a.dir:
        import json as _json
        bundles = {}
        for f in _expand(a.dir if isinstance(a.dir, str) else (a.source or ".")):
            b = api.bundle(str(f))
            bundles[f.stem] = b
            print(f"  {f.name}: {len(b['paths'])} paths")
        if a.out:
            pathlib.Path(a.out).write_text(_json.dumps(
                {"bundles": bundles}, indent=1))
        return 0
    b = api.bundle(a.source or a.dir if isinstance(a.dir, str) else a.source, out=a.out)
    print(f"bundle: {len(b['paths'])} paths, sha {b['source_sha256'][:12]}")
    return 0


def _cmd_lint(a) -> int:
    sys.argv = ["grammar_lint", *a.grammars]
    from tools import grammar_lint
    return grammar_lint.main(sys.argv)


def _cmd_extract(a) -> int:
    sys.argv = ["extract_grammar", a.upstream, a.out]
    from tools import extract_grammar
    return extract_grammar.main(sys.argv)


def _cmd_health(a) -> int:
    from pegrex import api
    spec = api.spec(a.path, pathlib.Path(a.path).stem + "_health",
                    out_dir="specs")
    print(f"wrote specs/{pathlib.Path(a.path).stem}_health.spec.json: "
          f"{len(spec['tasks'])} tasks")
    return 0


def _cmd_verify(a) -> int:
    import pipeline as pl
    pl.run_spec(a.spec)
    return 0


def _cmd_certs(a) -> int:
    import subprocess as sp
    ok = True
    for m in sorted((ROOT / "certs").glob("m*_*.py")) + [ROOT / "certs/demo.py"]:
        r = sp.run([sys.executable, str(m)], cwd=ROOT, capture_output=True)
        ok &= r.returncode == 0
        print(f"  {m.name:28} {'OK' if r.returncode == 0 else 'FAIL'}")
    for spec in ("fact", "chain", "absval"):
        r = sp.run([sys.executable, "pipeline.py", f"specs/{spec}.json"],
                   cwd=ROOT, capture_output=True)
        ok &= r.returncode == 0
    r = sp.run([sys.executable, "pipeline.py", "specs/fact_negative.json"],
               cwd=ROOT, capture_output=True)
    ok &= r.returncode != 0
    print("CERTS:", "ALL GREEN" if ok else "FAILURES")
    return 0 if ok else 1


def _cmd_rules(a) -> int:
    cat = json.loads((ROOT / "pegrex/secrules.json").read_text())
    tc = json.loads((ROOT / "pegrex/secrules_taint.json").read_text())
    if a.json:
        print(json.dumps({"pattern_rules": len(cat["rules"]),
                          "taint_rules": len(tc["rules"])}, indent=1))
    else:
        langs = {}
        for r in cat["rules"]:
            for l in r.get("langs", ["any"]):
                langs[l] = langs.get(l, 0) + 1
        print(f"pattern rules: {len(cat['rules'])}")
        print(f"taint rules:   {len(tc['rules'])}")
        print("by language:", dict(sorted(langs.items(),
                                          key=lambda kv: -kv[1])[:10]))
    return 0


def _cmd_serve(a) -> int:
    import runpy
    runpy.run_path(str(ROOT / "service.py"), run_name="__main__")
    return 0


def _cmd_acp(a) -> int:
    import runpy
    sys.argv = ["acp", a.root]
    runpy.run_module("pegrex.acp", run_name="__main__")
    return 0


def _cmd_mcp(a) -> int:
    from pegrex.mcp import MCPServer
    return MCPServer().serve()


def _cmd_induce(a) -> int:
    """FULL grammar induction: examples in, grammar out (written to --out)."""
    from pegrex.induce import induce
    pos = [l for l in pathlib.Path(a.positives).read_text().splitlines()
           if l.strip()]
    neg = [l for l in pathlib.Path(a.negatives).read_text().splitlines()
           if l.strip()] if a.negatives else []
    seed = pathlib.Path(a.seed).read_text() if a.seed \
        else "START <- .+\n"
    best, score = induce(pos, neg, seed, rounds=a.rounds)
    print(f"score: {score[0]}/{len(pos)} pos, {score[1]}/{len(neg)} neg")
    print(best)
    if a.out:
        pathlib.Path(a.out).write_text(best)
        print(f"wrote {a.out}")
    return 0


def _cmd_workrun(a) -> int:
    """FULL .work execution: run the agent, check its invariants."""
    import json as _json
    from pegrex.workexec import execute
    out = execute(a.work, a.target)
    print(_json.dumps(out, indent=1))
    return 0


def _cmd_metaengine(a) -> int:
    """FULL meta-engine: examples -> grammar -> tags -> rule skeletons."""
    from pegrex.metaengine import build_system
    pos = [l for l in pathlib.Path(a.positives).read_text().splitlines()
           if l.strip()]
    neg = [l for l in pathlib.Path(a.negatives).read_text().splitlines()
           if l.strip()] if a.negatives else []
    out = build_system(pos, neg, "START <- .+\n", domain=a.domain)
    print(json.dumps({k: out[k] for k in ("tags", "score")}, indent=1))
    print("rule skeletons:", len(out["rule_skeletons"]))
    if a.out:
        pathlib.Path(a.out).write_text(json.dumps(out, indent=1))
    return 0




def _cmd_ci(a) -> int:
    import json as _json
    from pegrex.ci import analyze_pipeline
    print(_json.dumps(analyze_pipeline(a.file), indent=1))
    return 0


def _cmd_osv(a) -> int:
    import json as _json
    from pegrex.sca import scan
    print(_json.dumps(scan(a.file), indent=1)[:3000])
    return 0


def _cmd_export(a) -> int:
    from tools.secaudit import audit as _audit
    from pegrex.export import export as _export
    findings = _audit(a.file)
    text = _export(findings, a.format, a.out, a.file)
    print(text[:3000] if text.strip() else
          f"{len(findings)} findings "
          f"(wrote {a.out})" if a.out else f"{len(findings)} findings")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="pegrex",
        description="Self-contained symbolic-execution and syntactic-analysis "
                    "engine: source -> mathematical specifications for AI agents.",
        epilog="certificates: `pegrex certs` runs all 67 proofs. "
               "Each command accepts -h.")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = p.add_subparsers(dest="command", metavar="<command>")

    sp = sub.add_parser("audit", help="security audit (patterns + taint + SCA)")
    sp.add_argument("file")
    sp.add_argument("--lang")
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(fn=_cmd_audit)

    sp = sub.add_parser("spec", help="AI spec schema (multi-view)")
    sp.add_argument("source", nargs="?")
    sp.add_argument("--dir", nargs="?", const=True, default=False,
                    metavar="PATH", help="recurse a directory")
    sp.add_argument("name")
    sp.add_argument("--out", default="specs")
    sp.add_argument("--opus", help="comma list of perspectives")
    sp.add_argument("--analyzers", help="comma list of analyzers")
    sp.set_defaults(fn=_cmd_spec)

    sp = sub.add_parser("contracts", help="function contract (paths -> results)")
    sp.add_argument("file")
    sp.add_argument("--lang", default="python")
    sp.set_defaults(fn=_cmd_contracts)

    sp = sub.add_parser("callgraph", help="function-call graph (DOT/ASCII)")
    sp.add_argument("file", nargs="?")
    sp.add_argument("--dir", nargs="?", const=True, default=False,
                    metavar="PATH",
                    help="recurse a directory (positional or this path)")
    sp.add_argument("--lang", default="python")
    sp.add_argument("--ascii", action="store_true")
    sp.set_defaults(fn=_cmd_callgraph)

    sp = sub.add_parser("coverage", help="path coverage overlay + gaps")
    sp.add_argument("source", nargs="?")
    sp.add_argument("--dir", nargs="?", const=True, default=False,
                    metavar="PATH", help="recurse a directory")
    sp.add_argument("--lcov", required=True)
    sp.add_argument("--lang", default="python")
    sp.set_defaults(fn=_cmd_coverage)

    sp = sub.add_parser("gaps", help="coverage gaps with constraint context")
    sp.add_argument("source")
    sp.add_argument("--lcov", required=True)
    sp.add_argument("--lang", default="python")
    sp.set_defaults(fn=_cmd_gaps)

    sp = sub.add_parser("tests", help="synthesize tests from coverage gaps")
    sp.add_argument("source")
    sp.add_argument("--lcov", required=True)
    sp.set_defaults(fn=_cmd_tests)

    sp = sub.add_parser("budget", help="complexity budget gate (exit 1 on fail)")
    sp.add_argument("file", nargs="?")
    sp.add_argument("--dir", nargs="?", const=True, default=False,
                    metavar="PATH", help="recurse a directory")
    sp.add_argument("--max-loc", type=int, default=300)
    sp.add_argument("--max-function-lines", type=int, default=40)
    sp.set_defaults(fn=_cmd_budget)

    sp = sub.add_parser("index", help="repo arch index")
    sp.add_argument("dir")
    sp.add_argument("--out", default="repo.index.json")
    sp.set_defaults(fn=_cmd_index)

    sp = sub.add_parser("bundle", help="portable verification bundle")
    sp.add_argument("source", nargs="?")
    sp.add_argument("--dir", nargs="?", const=True, default=False,
                    metavar="PATH", help="recurse a directory")
    sp.add_argument("--out")
    sp.set_defaults(fn=_cmd_bundle)

    sp = sub.add_parser("rules", help="rule catalog summary")
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(fn=_cmd_rules)

    sp = sub.add_parser("lint", help="grammar lint")
    sp.add_argument("grammars", nargs="+")
    sp.set_defaults(fn=_cmd_lint)

    sp = sub.add_parser("extract", help="verbatim grammar extraction")
    sp.add_argument("upstream")
    sp.add_argument("out")
    sp.set_defaults(fn=_cmd_extract)

    sp = sub.add_parser("induce", help="grammar induction (examples -> grammar)")
    sp.add_argument("positives", help="file of positive example lines")
    sp.add_argument("--negatives", help="file of negative example lines")
    sp.add_argument("--seed", help="seed grammar file")
    sp.add_argument("--out", help="write induced grammar here")
    sp.add_argument("--rounds", type=int, default=60)
    sp.set_defaults(fn=_cmd_induce)

    sp = sub.add_parser("workrun", help="execute a .work agent")
    sp.add_argument("work")
    sp.add_argument("--target", help="source file the agent analyzes")
    sp.set_defaults(fn=_cmd_workrun)

    sp = sub.add_parser("metaengine",
                        help="examples -> grammar -> tags -> rule skeletons")
    sp.add_argument("positives")
    sp.add_argument("--negatives")
    sp.add_argument("--domain", default="custom")
    sp.add_argument("--out")
    sp.set_defaults(fn=_cmd_metaengine)

    sp = sub.add_parser("health", help="self code-health spec")
    sp.add_argument("path")
    sp.set_defaults(fn=_cmd_health)

    sp = sub.add_parser("verify", help="translation certificate")
    sp.add_argument("spec")
    sp.set_defaults(fn=_cmd_verify)

    sp = sub.add_parser("cisec", help="CI/CD pipeline security analysis")
    sp.add_argument("file")
    sp.set_defaults(fn=_cmd_ci)
    sp = sub.add_parser("osvscan", help="dependency vulnerability scan (OSV)")
    sp.add_argument("file")
    sp.set_defaults(fn=_cmd_osv)
    sp = sub.add_parser("export", help="export findings (json/csv/html)")
    sp.add_argument("file")
    sp.add_argument("--format", default="json",
                    choices=["json", "csv", "html"])
    sp.add_argument("--out")
    sp.set_defaults(fn=_cmd_export)
    sp = sub.add_parser("certs", help="run ALL certificates + negative control")
    sp.set_defaults(fn=_cmd_certs)

    sp = sub.add_parser("serve", help="JSON-lines service (stdio)")
    sp.set_defaults(fn=_cmd_serve)

    sp = sub.add_parser("acp", help="ACP server (Zed-compatible)")
    sp.add_argument("root", nargs="?", default=".")
    sp.set_defaults(fn=_cmd_acp)

    sp = sub.add_parser("mcp", help="MCP server (tools + resources + router)")
    sp.set_defaults(fn=_cmd_mcp)

    return p


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not hasattr(args, "fn"):
        parser.print_help()
        return 0
    try:
        return args.fn(args)
    except KeyboardInterrupt:
        return 130
    except SystemExit as e:
        return e.code or 0


if __name__ == "__main__":
    sys.exit(main())
