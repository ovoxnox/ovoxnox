"""
╔══════════════════════════════════════════════════════════════════════════╗
║  s m t                                                                    ║
║  Self-contained solver for the path-constraint fragment (QF_LIA-ish):     ║
║  learn(atoms) -> model; entails(model, guard); feasible(model).           ║
║  Swap in z3 behind the Backend protocol when guards outgrow the fragment. ║
╚══════════════════════════════════════════════════════════════════════════╝
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

_ATOM = re.compile(r"^\((?P<var>[A-Za-z_]\w*)\s*(?P<op><=|>=|<|>|=)\s*(?P<k>-?\d+)\)$")
_NEG = re.compile(r"^\(not\s+\((?P<var>[A-Za-z_]\w*)\s*(?P<op><=|>=|<|>|=)\s*(?P<k>-?\d+)\)\)$")
_NEGATE = {"=": "!=", "<": ">=", "<=": ">", ">": "<=", ">=": "<"}


def _parse_atom(s: str):
    s = s.strip()
    if (m := _NEG.match(s)):
        return (_NEGATE[m.group("op")], m.group("var"), int(m.group("k")))
    if (m := _ATOM.match(s)):
        return (m.group("op"), m.group("var"), int(m.group("k")))
    return None


@dataclass
class Model:
    """Bounds model: var -> [lo, lo_inc, hi, hi_inc, neq]."""
    bounds: dict = field(default_factory=dict)

    def _entry(self, var: str):
        return self.bounds.setdefault(var, [None, True, None, True, set()])

    def add_atom(self, op: str, var: str, k: int) -> None:
        e = self._entry(var)
        if op == "=":
            e[0], e[1], e[2], e[3] = k, True, k, True
        elif op == "!=":
            e[4].add(k)
        elif op in ("<", "<="):
            inc = op == "<="
            if e[2] is None or k < e[2] or (k == e[2] and e[3] and not inc):
                e[2], e[3] = k, inc
        else:  # >, >=
            inc = op == ">="
            if e[0] is None or k > e[0] or (k == e[0] and e[1] and not inc):
                e[0], e[1] = k, inc

    def feasible(self) -> bool:
        for lo, li, hi, hi_inc, neq in self.bounds.values():
            if lo is not None and hi is not None:
                if lo > hi or (lo == hi and not (li and hi_inc)):
                    return False
                if lo == hi and lo in neq:
                    return False
        return True


def learn(atoms) -> Model:
    m = Model()
    for a in atoms:
        if (p := _parse_atom(str(a))):
            m.add_atom(*p)
    return m


def _entails_atom(m: Model, op: str, var: str, k: int) -> bool:
    lo, li, hi, hi_inc, neq = m.bounds.get(var, [None, True, None, True, set()])
    match op:
        case "=":
            return (lo is not None and hi is not None and lo == hi == k
                    and li and hi_inc and k not in neq)
        case "!=":
            if lo is not None and hi is not None and lo == hi:
                return lo != k or k in neq
            if lo is not None and (k < lo or (k == lo and not li)):
                return True
            if hi is not None and (k > hi or (k == hi and not hi_inc)):
                return True
            return False
        case "<":
            return hi is not None and (hi < k or (hi == k and not hi_inc))
        case "<=":
            return hi is not None and (hi < k or (hi == k and hi_inc))
        case ">":
            return lo is not None and (lo > k or (lo == k and not li))
        case ">=":
            return lo is not None and (lo > k or (lo == k and li))
    return False


def _split_top(s: str) -> list[str]:
    parts, depth, cur = [], 0, ""
    for ch in s:
        depth += (ch == "(") - (ch == ")")
        if ch == " " and depth == 0:
            if cur:
                parts.append(cur)
                cur = ""
        else:
            cur += ch
    return parts + ([cur] if cur else [])


def entails(model: Model, guard) -> bool:
    """True if every model of the learned atoms satisfies the guard."""
    s = str(guard).strip()
    if s.startswith("(and"):
        return all(entails(model, p) for p in _split_top(s[4:-1]))
    if s.startswith("(or"):
        return any(entails(model, p) for p in _split_top(s[3:-1]))
    if s.startswith("(not"):
        inner = s[4:-1].strip()
        if (p := _parse_atom(inner)) and p[0] in ("<", "<=", ">", ">="):
            return _entails_atom(model, _NEGATE[p[0]], p[1], p[2])
        if p and p[0] == "=":
            return _entails_atom(model, "!=", p[1], p[2])
        return False
    return _entails_atom(model, *_parse_atom(s)) if _parse_atom(s) else False


# ── backend seam ───────────────────────────────────────────────────────────
class Backend:
    """The only surface specgen/idioms consume. Swap in z3 by subclassing."""

    def learn(self, atoms):
        return learn(atoms)

    def entails(self, model, guard):
        return entails(model, guard)

    def feasible(self, model):
        return model.feasible()


_default = Backend()


def get_backend() -> Backend:
    return _default


def set_backend(backend: Backend) -> None:
    global _default
    _default = backend




# ── auto-escalation: fragment detection + optional z3 ─────────────────────
def _fragment_exceeded(atoms) -> bool:
    """True if atoms leave the single-variable linear fragment
    (multi-variable atoms or non-constant right-hand sides)."""
    import re as _re
    for a in map(str, atoms):
        vars_ = set(_re.findall(r"[A-Za-z_]\w*(?=@|\b)", a))
        vars_ = {v for v in vars_ if not v.isdigit()
                 and v not in ("not", "and", "or")}
        nums = _re.findall(r"-?\d+", a)
        if len(vars_) > 1 or (vars_ and not nums):
            return True
    return False


def auto_feasible(atoms) -> bool:
    """Bounds-engine by default; z3 when the fragment is exceeded AND z3
    is importable.  Zero cost when z3 is absent."""
    if not _fragment_exceeded(atoms):
        return learn(atoms).feasible()
    try:
        return Z3Backend().feasible(list(atoms))
    except ImportError:
        return learn(atoms).feasible()   # best effort in-fragment
