"""
╔══════════════════════════════════════════════════════════════════════════╗
║  c f g                                                                    ║
║  Control-flow graphs from any AST: tag names OR callables, transparent    ║
║  wrappers, Rust tail-expressions as implicit returns.                     ║
╚══════════════════════════════════════════════════════════════════════════╝
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from .peg import Node

NL = chr(10)


@dataclass
class Block:
    id: int
    stmts: list = field(default_factory=list)
    term: str = "fall"          # fall | branch | loopcond | ret


@dataclass
class Edge:
    src: int
    dst: int
    cond: object = None         # symbolic guard (None = unconditional)
    kind: str = "flow"          # flow | then | else | body | exit | back


@dataclass
class TagSpec:
    """Dispatch table. Fields accept a tag name (str) or a callable over the
    Node-children list: if_ -> (cond, then, else|None); while_ -> (cond, body)."""
    block: object = "Block"
    if_: object = "If"
    while_: object = "While"
    for_: object = "For"                     # counting loops over iterables
    try_: object = "Try"                     # exception edges: body -> handlers
    return_: str = "Return"
    break_: str = "Break"
    continue_: str = "Continue"   # edges back to the loop header
    match_: object = "Match"
    with_: object = "With"      # multi-way branch: one edge per arm
    tail_return: tuple = ()     # rust: bare tail expressions are results

    _nodes = staticmethod(lambda n: [c for c in n.children
                                     if isinstance(c, Node)])

    def if_parts(self, node):
        ch = self._nodes(node)
        return (self.if_(ch) if callable(self.if_)
                else (ch[0], ch[1], ch[2] if len(ch) > 2 else None))

    def while_parts(self, node):
        ch = self._nodes(node)
        return (self.while_(ch) if callable(self.while_)
                else (ch[0], ch[1]))

    def for_parts(self, node):
        ch = self._nodes(node)
        return (self.for_(ch) if callable(self.for_)
                else (ch[0], ch[1]))


class CFG:
    def __init__(self) -> None:
        self.blocks: list[Block] = []
        self.edges: list[Edge] = []

    def add_block(self, stmts=(), term: str = "fall") -> int:
        self.blocks.append(Block(len(self.blocks), list(stmts), term))
        return self.blocks[-1].id

    def add_edge(self, src: int, dst: int, cond=None, kind: str = "flow") -> None:
        self.edges.append(Edge(src, dst, cond, kind))

    def successors(self, b: int):
        return [(e.dst, e) for e in self.edges if e.src == b]

    def to_dot(self) -> str:
        head = "digraph cfg {"
        nodes = [f'  b{b.id} [shape=box,label="b{b.id}: '
                 + ("\\l".join(getattr(x, "tag", str(x)) for x in b.stmts)
                    or b.term) + '\\l"]'
                 for b in self.blocks]
        edges = [f'  b{e.src} -> b{e.dst} [label="{e.kind}"]' for e in self.edges]
        return NL.join([head, *nodes, *edges, "}"])


class CFGBuilder:
    _TRANSPARENT = ("statement_list", "expression_statement", "statement",
                    "function_body", "statements", "infix_expression",
                    "block_expression")

    def __init__(self, spec: TagSpec | None = None) -> None:
        self.spec = spec or TagSpec()
        self.cfg = CFG()

    def build(self, node) -> CFG:
        self._stmt(node, self.cfg.add_block())
        return self.cfg

    def _stmt(self, node, cur: int):
        if not isinstance(node, Node):
            return cur, None
        if node.tag in self._TRANSPARENT:    # go statement_list / rust expr stmt
            for ch in node.children:
                if isinstance(ch, Node):
                    cur, brk = self._stmt(ch, cur)
                    if brk is not None:
                        return cur, brk
            return cur, None
        sp, tag = self.spec, node.tag
        if tag == "elif_clause":            # tree-sitter: flat elif chains
            kids = [c for c in node.children if isinstance(c, Node)]
            els = kids[2] if len(kids) > 2 else None
            if els is not None and els.tag == "else_clause":
                inner = [c for c in els.children if isinstance(c, Node)]
                els = inner[-1] if inner else els
            return self._if(kids[0], kids[1], els, cur)
        if tag == sp.block:
            return self._block(node, cur)
        if tag == sp.if_ or (callable(sp.if_)
                             and tag == getattr(sp.if_, "_tag", None)):
            cond, then, els = sp.if_parts(node)
            return self._if(cond, then, els, cur)
        if tag == sp.while_ or (callable(sp.while_)
                                and tag == getattr(sp.while_, "_tag", None)):
            cond, body = sp.while_parts(node)
            return self._while(cond, body, cur)
        if tag == sp.for_ or (callable(sp.for_)
                              and tag == getattr(sp.for_, "_tag", None)):
            cond, body = sp.for_parts(node)
            return self._while(cond, body, cur)   # same shape: header + body
        if tag == sp.try_ or (callable(sp.try_)
                              and tag == getattr(sp.try_, "_tag", None)):
            return self._try(node, cur)
        if tag == sp.match_ or (callable(sp.match_)
                                and tag == getattr(sp.match_, "_tag", None)):
            return self._match(node, cur)
        if tag == sp.with_ or (callable(sp.with_)
                               and tag == getattr(sp.with_, "_tag", None)):
            return self._with(node, cur)
        if tag == sp.with_ or (callable(sp.with_)
                               and tag == getattr(sp.with_, "_tag", None)):
            return self._with(node, cur)
        if tag == sp.return_:
            return self._terminate(cur, node)
        if tag == sp.break_:
            return self.cfg.add_block(), cur
        if tag == sp.continue_:
            return self.cfg.add_block(), ("continue", cur)
        self.cfg.blocks[cur].stmts.append(node)
        return cur, None

    def _block(self, node, cur: int):
        kids = [c for c in node.children if isinstance(c, Node)]
        for i, ch in enumerate(kids):
            if i == len(kids) - 1 and self.spec.tail_return:
                inner = ch
                while inner.tag in self._TRANSPARENT and inner.children:
                    inner = inner.children[0]
                if inner.tag in self.spec.tail_return:
                    return self._terminate(cur, ch)
            cur, brk = self._stmt(ch, cur)
            if brk is not None:
                return cur, brk
        return cur, None

    def _terminate(self, cur: int, node):
        self.cfg.blocks[cur].stmts.append(node)
        self.cfg.blocks[cur].term = "ret"
        return self.cfg.add_block(), None

    def _if(self, cond, then, els, cur: int):
        self.cfg.blocks[cur].term = "branch"
        t_entry = self.cfg.add_block()
        self.cfg.add_edge(cur, t_entry, cond, "then")
        t_end, tbrk = self._stmt(then, t_entry)
        e_end = ebrk = None
        if els is not None:
            e_entry = self.cfg.add_block()
            self.cfg.add_edge(cur, e_entry, (cond, "else"), "else")
            e_end, ebrk = self._stmt(els, e_entry)
        join = self.cfg.add_block()
        self.cfg.add_edge(tbrk if tbrk is not None else t_end, join)
        if els is not None:
            self.cfg.add_edge(ebrk if ebrk is not None else e_end, join)
        else:
            self.cfg.add_edge(cur, join, (cond, "else"), "else")
        return join, None

    def _match(self, node, cur):
        """Multi-way branch: subject + one edge per arm block."""
        kids = [c for c in node.children if isinstance(c, Node)]
        subject = kids[0] if kids else None
        arms = []
        for k in kids[1:]:
            arms.extend(c for c in k.children
                        if isinstance(c, Node)
                        and ("case" in c.tag or c.tag == "switch_case"))
        self.cfg.blocks[cur].term = "branch"
        join = self.cfg.add_block()
        for arm in arms:
            inner = arm
            sub = [c for c in inner.children if isinstance(c, Node)]
            inner = sub[-1] if sub else inner
            entry = self.cfg.add_block()
            self.cfg.add_edge(cur, entry, (subject, arm), "arm")
            end, brk = self._stmt(inner, entry)
            self.cfg.add_edge(brk if brk is not None else end, join)
        return join, None

    def _try(self, node, cur):
        """try body + except handlers as alternative paths (conservative
        exception edges from try-entry to each handler)."""
        kids = [c for c in node.children if isinstance(c, Node)]
        body, handlers = kids[0], [k for k in kids[1:]
                                   if "except" in k.tag or k.tag == "block"]
        t_entry = self.cfg.add_block()
        self.cfg.add_edge(cur, t_entry, kind="try")
        t_end, tbrk = self._stmt(body, t_entry)
        join = self.cfg.add_block()
        if tbrk is None:
            self.cfg.add_edge(t_end, join, kind="noexcept")
        else:
            self.cfg.add_edge(tbrk, join)
        for h in handlers:
            h_entry = self.cfg.add_block()
            self.cfg.add_edge(t_entry, h_entry, ("<exception>", h.tag), "raise")
            h_end, hbrk = self._stmt(h, h_entry)
            self.cfg.add_edge(hbrk if hbrk is not None else h_end, join)
        return join, None

    def _with(self, node, cur):
        """Context manager: [context_expr, body_block]."""
        kids = [c for c in node.children if isinstance(c, Node)]
        if not kids:
            return cur, None
        body = kids[1] if len(kids) > 1 else kids[0]
        enter = self.cfg.add_block()
        self.cfg.add_edge(cur, enter, kind="enter")
        b_end, brk = self._stmt(body, enter)
        after = self.cfg.add_block()
        self.cfg.add_edge(b_end if brk is None else brk, after, kind="exit")
        self.cfg.add_edge(enter, after, ("<exception>", "with"), "raise")
        return after, None

    def _while(self, cond, body, cur: int):
        self.cfg.blocks[cur].term = "loopcond"
        body_entry = self.cfg.add_block()
        self.cfg.add_edge(cur, body_entry, cond, "body")
        b_end, brk = self._stmt(body, body_entry)
        continues, brk = ([brk[1]] if isinstance(brk, tuple) and brk[0] == "continue"
                          else [], None if isinstance(brk, tuple) else brk)
        for cblk in continues:
            self.cfg.add_edge(cblk, cur, kind="back")   # continue -> header
        if brk is None:
            self.cfg.add_edge(b_end, cur, kind="back")
        after = self.cfg.add_block()
        self.cfg.add_edge(cur, after, (cond, "exit"), "exit")
        if brk is not None:
            self.cfg.add_edge(brk, after)
        return after, None


def enumerate_paths_lazy(node, tagspec=None, unroll: int = 1):
    """Lazy path enumeration: walk the AST yielding paths WITHOUT building
    the full CFG upfront.  Blocks materialize only where execution reaches;
    a 10,000-block transpiled bundle costs blocks only on visited paths."""
    spec = tagspec or TagSpec()
    counter = [0]
    backs = [set()]

    def block():
        counter[0] += 1
        return counter[0]

    def rec(n, path, visits):
        if not isinstance(n, Node):
            yield from []
            return
        if n.tag in CFGBuilder._TRANSPARENT:
            acc = [block()]
            for ch in n.children:
                if isinstance(ch, Node):
                    for p in rec(ch, path + acc, visits):
                        yield p
            return
        tag = n.tag
        kids = [x for x in n.children if isinstance(x, Node)]
        if tag == spec.return_:
            yield path + [block()]
            return
        if tag == spec.break_:
            yield path + [("break",)]
            return
        if tag == spec.block:
            acc = [block()]
            for ch in kids:
                for p in rec(ch, path + acc, visits):
                    yield p
            return
        if tag == spec.if_ or (callable(spec.if_)
                               and tag == getattr(spec.if_, "_tag", None)):
            cond, then, els = spec.if_parts(n)
            for p in rec(then, path + [block()], visits):
                yield p
            if els is not None:
                for p in rec(els, path + [block()], visits):
                    yield p
            else:
                yield path + [block()]
            return
        if tag == spec.while_ or (callable(spec.while_)
                                  and tag == getattr(spec.while_, "_tag", None)):
            cond, body = spec.while_parts(n)
            head = block()
            yield path + [head]
            key = id(n)
            if visits.get(key, 0) < unroll:
                for p in rec(body, path + [head, block()],
                             {**visits, key: visits.get(key, 0) + 1}):
                    yield p
            return
        yield path + [block()]

    yield from rec(node, [], {})
