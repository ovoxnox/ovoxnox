"""
╔══════════════════════════════════════════════════════════════════════════╗
║  e x p o r t -- multi-format reporting (JSON / CSV / HTML)               ║
╚══════════════════════════════════════════════════════════════════════════╝
"""
from __future__ import annotations

import csv
import html
import io
import json


def to_csv(findings: list) -> str:
    buf = io.StringIO()
    if not findings:
        return ""
    w = csv.DictWriter(buf, fieldnames=sorted(findings[0].keys()),
                       extrasaction="ignore")
    w.writeheader()
    w.writerows(findings)
    return buf.getvalue()


def to_html(findings: list, title: str = "pegrex report") -> str:
    rows = "".join(
        "<tr><td>{sev}</td><td>{id}</td><td>{line}</td>"
        "<td>{ev}</td></tr>".format(
            sev=html.escape(str(f.get("severity", ""))),
            id=html.escape(str(f.get("id", ""))),
            line=f.get("line", ""),
            ev=html.escape(str(f.get("evidence", f.get("message", "")))[:120]))
        for f in findings)
    return ("<!doctype html><meta charset='utf-8'>"
            f"<title>{html.escape(title)}</title>"
            "<style>body{font-family:sans-serif;margin:2em}"
            "td,th{border:1px solid #ccc;padding:4px 10px}"
            "th{background:#eee}</style>"
            f"<h1>{html.escape(title)}</h1>"
            f"<p>{len(findings)} finding(s)</p>"
            "<table><tr><th>Severity</th><th>Rule</th><th>Line</th>"
            f"<th>Evidence</th></tr>{rows}</table>")


def export(findings: list, fmt: str, out: str | None = None,
           title: str = "pegrex report") -> str:
    text = (json.dumps(findings, indent=1) if fmt == "json"
            else to_csv(findings) if fmt == "csv"
            else to_html(findings, title))
    if out:
        import pathlib
        pathlib.Path(out).write_text(text)
    return text
