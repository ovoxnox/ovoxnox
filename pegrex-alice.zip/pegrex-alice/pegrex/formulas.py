"""
╔══════════════════════════════════════════════════════════════════════════╗
║  f o r m u l a s                                                          ║
║  Symbolic core: every execution path becomes one mathematical formula.    ║
║  Immutable Op trees; SMT-LIB export; bounded path enumeration.            ║
╚══════════════════════════════════════════════════════════════════════════╝
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Sym:
    name: str
    def __str__(self) -> str: return self.name


@dataclass(frozen=True)
class Op:
    op: str
    args: tuple
    def __str__(self) -> str:
        if self.op == "not" and len(self.args) == 1:
            return f"(not {self.args[0]})"
        if self.op == "ite" and len(self.args) == 3:
            return f"(ite {self.args[0]} {self.args[1]} {self.args[2]})"
        return "(" + f" {self.op} ".join(str(a) for a in self.args) + ")"


def const(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    return v


def V(name: str) -> Sym: return Sym(name)
def And(*a): return Op("and", tuple(a))
def Or(*a):  return Op("or", tuple(a))
def Not(a):  return Op("not", (a,))
def Eq(a, b): return Op("=", (a, b))
def Lt(a, b): return Op("<", (a, b))
def Le(a, b): return Op("<=", (a, b))
def Gt(a, b): return Op(">", (a, b))
def Ge(a, b): return Op(">=", (a, b))
def Add(a, b): return Op("+", (a, b))
def Sub(a, b): return Op("-", (a, b))
def Mul(a, b): return Op("*", (a, b))
def ite(c, t, e): return Op("ite", (c, t, e))

OPS_TXT = {"<": Lt, "<=": Le, ">": Gt, ">=": Ge,
           "==": Eq, "!=": lambda a, b: Not(Eq(a, b))}


@dataclass
class PathFormula:
    blocks: list
    ssa: dict = field(default_factory=dict)
    constraints: list = field(default_factory=list)
    _SYM: "re.Pattern" = field(default=re.compile(r"(?<=[\s(])([A-Za-z_][\w@]*)"),
                               repr=False)

    def smt2(self) -> str:
        kw = {"not", "and", "or", "ite", "true", "false"}
        names = [n.replace("@", "_") for src in map(str, self.constraints)
                 for n in self._SYM.findall(src) if n not in kw]
        nl = chr(10)
        decls = nl.join(f"(declare-fun {n} () Int)" for n in dict.fromkeys(names))
        body = nl.join(f"(assert {str(c).replace(chr(64), chr(95))})"
                       for c in self.constraints)
        return nl.join(["(set-logic QF_NIA)", decls, body, "(check-sat)", ""])

class PathEnumerator:
    """Enumerate CFG paths; loops unrolled at most `unroll` times."""

    def __init__(self, cfg, unroll: int = 2) -> None:
        self.cfg, self.unroll = cfg, unroll
        self._backs = {(e.src, e.dst) for e in cfg.edges if e.kind == "back"}

    def enumerate(self, entry: int = 0) -> list[list[int]]:
        paths: list[list[int]] = []

        def dfs(b: int, visits: dict, acc: tuple) -> None:
            acc += (b,)
            if self.cfg.blocks[b].term == "ret" or not self.cfg.successors(b):
                paths.append(list(acc))
                return
            for dst, e in self.cfg.successors(b):
                key = (e.src, e.dst)
                if key in self._backs and visits.get(key, 0) >= self.unroll:
                    continue
                v2 = dict(visits)
                if key in self._backs:
                    v2[key] = v2.get(key, 0) + 1
                dfs(dst, v2, acc)

        dfs(entry, {}, ())
        return paths


def linearize(cfg, path, stmt_expr=None) -> PathFormula:
    """SSA-linearize one path into assignments + a constraint conjunction."""
    env, cons, version = {}, [], {}

    def fresh(n: str) -> str:
        version[n] = version.get(n, 0) + 1
        return f"{n}@{version[n]}"

    for i, b in enumerate(path):
        for st in cfg.blocks[b].stmts:
            if stmt_expr and (f := stmt_expr.get(st.tag)):
                nm, expr = f(st, env)
                env[nm] = Sym(fresh(nm))
                cons.append(Eq(env[nm], expr))
        if i + 1 < len(path):
            for dst, e in cfg.successors(b):
                if dst != path[i + 1] or e.cond is None:
                    continue
                if e.kind in ("then", "body"):
                    cons.append(e.cond)
                elif e.kind in ("else", "exit"):
                    c = e.cond[0] if isinstance(e.cond, tuple) else e.cond
                    cons.append(Not(c))
    return PathFormula(list(path), env, cons)
