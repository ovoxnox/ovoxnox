"""
╔══════════════════════════════════════════════════════════════════════════╗
║  p a t h s                                                                ║
║  Path formulas: bounded enumeration over CFGs, SSA linearization,        ║
║  SMT-LIB export.  Every execution path becomes one formula.              ║
╚══════════════════════════════════════════════════════════════════════════╝
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .sym import Not, Sym

NL = chr(10)


@dataclass
class PathFormula:
    blocks: list
    ssa: dict = field(default_factory=dict)
    constraints: list = field(default_factory=list)
    _SYM: "re.Pattern" = field(
        default=re.compile(r"(?<=[\s(])([A-Za-z_][\w@]*)"), repr=False)

    def smt2(self) -> str:
        kw = {"not", "and", "or", "ite", "true", "false"}
        names = [n.replace("@", "_") for src in map(str, self.constraints)
                 for n in self._SYM.findall(src) if n not in kw]
        decls = NL.join(f"(declare-fun {n} () Int)" for n in dict.fromkeys(names))
        body = NL.join(f"(assert {str(c).replace('@', '_')})"
                       for c in self.constraints)
        return NL.join(["(set-logic QF_NIA)", decls, body, "(check-sat)", ""])


class PathEnumerator:
    """Enumerate CFG paths; loops unrolled at most `unroll` times."""

    def __init__(self, cfg, unroll: int = 2) -> None:
        self.cfg, self.unroll = cfg, unroll
        self._backs = {(e.src, e.dst) for e in cfg.edges if e.kind == "back"}

    def enumerate(self, entry: int = 0) -> list[list[int]]:
        paths: list[list[int]] = []

        def dfs(b: int, visits: dict, acc: tuple) -> None:
            acc += (b,)
            if self.cfg.blocks[b].term == "ret" or not self.cfg.successors(b):
                paths.append(list(acc))
                return
            for dst, e in self.cfg.successors(b):
                key = (e.src, e.dst)
                if key in self._backs and visits.get(key, 0) >= self.unroll:
                    continue
                v2 = dict(visits)
                if key in self._backs:
                    v2[key] = v2.get(key, 0) + 1
                dfs(dst, v2, acc)

        dfs(entry, {}, ())
        return paths


def linearize(cfg, path, stmt_expr=None) -> PathFormula:
    """SSA-linearize one path into assignments + a constraint conjunction."""
    from .sym import Eq
    env, cons, version = {}, [], {}

    def fresh(n: str) -> str:
        version[n] = version.get(n, 0) + 1
        return f"{n}@{version[n]}"

    for i, b in enumerate(path):
        for st in cfg.blocks[b].stmts:
            if stmt_expr and (f := stmt_expr.get(st.tag)):
                nm, expr = f(st, env)
                env[nm] = Sym(fresh(nm))
                cons.append(Eq(env[nm], expr))
        if i + 1 < len(path):
            for dst, e in cfg.successors(b):
                if dst != path[i + 1] or e.cond is None:
                    continue
                if e.kind in ("then", "body"):
                    cons.append(e.cond)
                elif e.kind in ("else", "exit"):
                    c = e.cond[0] if isinstance(e.cond, tuple) else e.cond
                    cons.append(Not(c))
    return PathFormula(list(path), env, cons)
