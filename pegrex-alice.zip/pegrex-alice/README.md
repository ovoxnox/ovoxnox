# pegrex

**A self-contained symbolic-execution and syntactic-analysis engine that turns source code — in thirteen languages — into mathematical specifications for AI agents.**

Parse → project → solve → rewrite → verify → certify. 49 engine modules, 70 executable certificates, three agent protocols, one CLI.

---

## What it is

pegrex is a single Python codebase (required dependency: `pydantic`; tree-sitter grammars vendored in `.vendor/py`) that:

1. **Parses** Python, Go, Rust, JavaScript, TypeScript (incl. AssemblyScript), C, Solidity, Julia, Kotlin, and Zig via tree-sitter; C via a from-scratch port of the [lpegrex](https://github.com/edubart/lpegrex) PEG grammar compiler; Rust MIR and MLIR via regex-native compiler-IR frontends; Vyper via a hand-written lpegrex grammar. Grammar *text* is portable data: 13 grammar formats compile under one audited compiler.
2. **Projects** every function to mathematics: CFGs (SSA-normalized, 20+ control-flow constructs), bounded path enumeration, First-Order path constraints, function contracts `(constraints → result)`, closed-form loop summaries, call graphs, weakest preconditions, interval abstract interpretation.
3. **Solves** with a self-contained SMT core (bounds/disequalities over the path-constraint fragment; `z3` slots in behind a `Backend` protocol) — guard implication, infeasible-path pruning, concrete input models.
4. **Rewrites** with guard-checked idioms (SMT-proven path guards → target-language templates, compiled and runtime-verified), equality-saturation (e-graph) rewriting, synthesized tests from coverage gaps, Sketch-style program synthesis from constraints.
5. **Verifies** cross-language: identical path constraints, identical contracts, modular + transitive + cross-file composition, and bisimulation — each an executable certificate, with a negative control that must refuse.

Everything an AI agent needs for a closed TDD loop — violations, path boundaries with input constraints, synthesized tests, spec schemas validated by their own rejection tests — is emitted as deterministic JSON.

---

## Installation

```bash
pip install pydantic tree-sitter tree-sitter-python tree-sitter-go             tree-sitter-rust tree-sitter-javascript tree-sitter-solidity             tree-sitter-julia tree-sitter-kotlin tree-sitter-zig tree-sitter-typescript
# (tree-sitter bindings are also vendored in .vendor/py — no install needed there)
```

## Quick start

```bash
python run_tests.py          # 68 unit tests
python pegrex.py certs       # all 67 certificates + negative control
python demo.py               # (in certs/) end-to-end walkthrough
```

## CLI (25 commands)

`pegrex <command> -h` documents everything. Directory recursion: pass a directory with `--dir` (callgraph, budget, coverage, spec, bundle).

| Command | What it does |
|---|---|
| `audit <file> [--json]` | security audit: 691 pattern rules + 87 taint rules + SCA (go.mod / Cargo.lock / package-lock.json) |
| `spec <src> <name> [--dir]` | multi-view AI spec schema (6 analyzers × 5 opus perspectives) with machine-checkable verify commands |
| `contracts <file>` | per-path `(constraints → result)` contract |
| `callgraph <file-or-dir> [--ascii]` | function-call graph, DOT or terminal tree |
| `coverage <src> --lcov F [--dir]` | path-coverage overlay + gaps **with constraint context** |
| `gaps <src> --lcov F` | uncovered satisfiable paths + their input constraints |
| `tests <src> --lcov F` | synthesized pytest tests (concrete inputs from SMT models) |
| `budget <file-or-dir> [--max-loc N]` | complexity gate, exit 1 on breach |
| `index <dir>` | repo arch index (LLM-navigable containers/modules/owns) |
| `bundle <src> [--dir]` | portable verification bundles (sha + paths + SMT-LIB) |
| `rules [--json]` | catalog statistics by language |
| `cisec <workflow.yml>` | CI/CD pipeline security (5 anti-pattern classes) |
| `osvscan <lockfile>` | dependency vulnerability scan (OSV.dev, cached, offline-safe) |
| `export <file> --format {json,csv,html}` | multi-format findings reports |
| `lint <gram...>` | grammar hygiene (incl. the fatal-`@`-in-repetition check) |
| `extract <parser.lua> <out.gram>` | verbatim grammar extraction |
| `induce <pos.txt> [--negatives --seed --out]` | grammar induction from examples |
| `workrun <agent.work> [--target]` | execute a .work agent on the engine |
| `metaengine <pos.txt> [--negatives]` | examples → grammar → tags → rule skeletons |
| `health <path>` | self code-health spec |
| `verify <spec.json>` | translation certificate (or refusal) |
| `certs` | all 67 certificates + specs + negative control |
| `serve` / `acp [root]` / `mcp` | three agent protocols (below) |

## Agent protocols

- **JSON-lines service** (`python service.py`): `parse`, `contracts`, `gaps`, `fix` (finding-local repair context), `verify`, `callgraph` — stdin/stdout, one JSON object per line.
- **ACP** (`python pegrex.py acp`): Zed Agent Client Protocol — `session/prompt` with natural-language shortcuts, 6 tools, RAG-grounded retrieval.
- **MCP** (`python -m pegrex.mcp`): Model Context Protocol — 6 engine tools, rule catalogs as resources, and `MCPRouter`: prefix-based proxying over upstream MCP servers (pegrex as an aggregation layer).

## Feature map (46 engine modules)

| Layer | Modules |
|---|---|
| Parsing | `peg.py` (packrat LPeg/LPegLabel port), `compiler.py` (grammar-text compiler, 13 formats), `tree_sitter_bridge.py`, frontends in `pipeline.py`, `callgraph.py` |
| CFG | `cfg.py` (if/elif/loops/for/match/with/try, break/continue, transparent wrappers, tail returns, lazy `enumerate_paths_lazy`), `ssa.py` |
| Analysis | `paths.py`, `sym.py`, `smt.py` (+z3 seam, auto-escalation), `wp.py`, `abstract.py`, `egraphs.py`, `proofrepair.py`, `bisim.py` |
| Contracts | `summaries.py` (modular/transitive/cross-file composition), `coverage.py`, `testsynth.py`, `recursion.py` (memoization-aware) |
| Security | `patterns.py`, `taint.py` (inter-procedural + three-valued strict mode), `parallel.py` (OpenMP/PyOMP races), `ownership.py` |
| AI | `tokenizer.py` (INDENT/DEDENT), `mini_llm.py` (n-gram LM), `rag.py` (BM25-lite), `synthesize.py`, `formalize.py` (NL→invariants) |
| Verification | `modelcheck.py` (policy-IR state machines), `protocol.py`, `legal.py`, `circuit.py`, `passverify.py`, `transpiler.py` |
| Grammar tech | `gramir.py` (DSL as data: lift/lower/to_dsl), `induce.py`, `metaengine.py` |
| Schemas | `specs.py` (AgentReport + policy-IR states/transitions/assertions), `contract.py` (schema-by-rejection-tests), `extension.py`, `workflow.py`, `budget.py`, `cache.py` |
| Surfaces | `cli.py` (22 argparse commands), `acp.py`, `mcp.py`, `service.py`, `api.py` (50+ function unified API) |

## Certificates (M3–M70, in `certs/`)

One executable proof per feature: cross-language path/contract equality (m3–m5, m9, m25), loops and closed forms (m7, m10, m11, m13), guard-checked rewriting with gcc runtime verification (m6), dual-parser equivalence (m12), coverage with constraint context + test synthesis (m22, m24, m32), MIR/MLIR frontends (m23, m38), induction (m20, m40), bisimulation (m18), budget gates (m37), lazy CFG (m36), call graphs (m50), WP/abstract/e-graphs/model-checking/protocol/legal/circuit/synthesis/formalization (m51–m60, m65), CI/CD security (m68), OSV scanning (m69), multi-format export (m70), meta-engine (m64), MCP (m67), and the negative control that must refuse.

Run them all: `python pegrex.py certs`.

## Security stack

691 pattern rules (three auto-converted semgrep corpora via `tools/convert_semgrep.py` + hand packs for radare2 injection, GPU/WebGPU, Solidity, JS core sinks) + 87 taint rules (incl. `strict_missing` three-valued mode) + SCA for three package ecosystems. Rules are **data** — extend by adding JSON, validated by the contract layer.

## Research lineage (corpus in `.research*`)

- spec-kit `tests/contract` → `contract.py` (schemas defined by rejection tests); `extensions` → `extension.py`
- micsh/arch → `arch_index` artifacts in every spec
- microsoft/AgentSchema → AgentReport/Manifest split, Policy, Workflow
- wellmanifest/policy-dsl → policy-IR states/transitions/assertions
- openworklang → the `.work` agent DSL (`examples/agent.gram` + `work.py` + `workexec.py`)
- ash_rules → three-valued taint semantics
- hivm-spec → MLIR frontend + induction benchmark corpus

## Development

```bash
python run_tests.py                    # 68 tests
python tools/grammar_lint.py examples/*.gram
python pegrex.py certs                 # the full proof suite
```

Conventions: whole-file rewrites over patch chains; every feature ships with a certificate the same day; the negative control must always refuse; contracts validate manifests; budgets gate growth.

## Status

- **Gate: ALL GREEN** — 68 unit tests + 70 certificate checks + negative control
- 13 grammar formats, 13 language surfaces, 3 agent protocols
- pyproject.toml + LICENSE + CI workflow (tests + certs + grammar lint)

License: MIT (original lpegrex grammar-compiler semantics © Eduardo Bart, MIT).
