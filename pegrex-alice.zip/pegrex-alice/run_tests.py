#!/usr/bin/env python
"""Dependency-free test runner; delegates to pytest when importable."""
import importlib
import importlib.util
import subprocess
import sys

MODULES = ("tests.test_json", "tests.test_c11",
           "tests.test_pipeline", "tests.test_idioms", "tests.test_summaries",
           "tests.test_compose", "tests.test_smt", "tests.test_m5",
           "tests.test_chain", "tests.test_m6", "tests.test_grammars",
           "tests.test_service", "tests.test_bridge", "tests.test_loops",
           "tests.test_m8", "tests.test_m9", "tests.test_go_client",
           "tests.test_python_frontend", "tests.test_m10", "tests.test_tokenizer", "tests.test_mini_llm", "tests.test_gramir", "tests.test_contract", "tests.test_extension")


def main() -> int:
    if importlib.util.find_spec("pytest"):           # richer reporting when present
        code = subprocess.call([sys.executable, "-m", "pytest",
                                "tests/", "-q", "--tb=short"])
        if code == 0:
            return 0                                 # fall through to shim on env quirks
    failures = 0
    for modname in MODULES:
        mod = importlib.import_module(modname)
        for name in sorted(dir(mod)):
            if not name.startswith("test_"):
                continue
            try:
                getattr(mod, name)()
                print(f"PASS {modname}.{name}")
            except Exception as e:  # noqa: BLE001
                failures += 1
                print(f"FAIL {modname}.{name}: {e!r}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
