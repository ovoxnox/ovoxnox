# Usage Guide

## 0. Install

    pip install pydantic tree-sitter tree-sitter-python tree-sitter-go tree-sitter-rust

## 1. Analyze Python source (the AI debugging interface)

```python
from pegrex.tree_sitter_bridge import ts_to_pegrex, TAGSPECS
from pegrex.specgen import analyze
from pegrex.patterns import Pattern
from pegrex.formulas import V, const, Eq, Lt, Le, Gt, Ge, Not
import re, tree_sitter_python
from tree_sitter import Language, Parser

SRC = "def absval(n):\n    if n > 0:\n        return n\n    return -n\n"
root = Parser(Language(tree_sitter_python.language())).parse(SRC.encode()).root_node
tree = ts_to_pegrex(root, SRC)

OPS = {"<": Lt, "<=": Le, ">": Gt, ">=": Ge,
       "==": Eq, "!=": lambda a, b: Not(Eq(a, b))}

def cond(node, src):
    txt = src[node.pos:node.endpos]
    m = re.match(r"\s*([A-Za-z_]\w*)\s*(<=|>=|<|>|==|!=)\s*(-?\d+)", txt.strip())
    return OPS[m.group(2)](V(m.group(1)), const(int(m.group(3))))

rules = [Pattern(node_type="return_statement", text=r"return\s+-",
                 id="negated-return")]

report = analyze(tree, "python", "absval", rules=rules,
                 tagspec=TAGSPECS["python"], src=SRC, cond=cond,
                 render=lambda st, s=SRC: s[st.pos:st.endpos].replace("return", "").strip())
print(report.to_agent_json())
```

Output (abridged): paths with constraints `["(n > 0)"]` / `["(not (n > 0))"]`,
violation `negated-return` at bytes 40-50, `z3: {paths_total: 2, paths_satisfiable: 2}`.
This JSON is the prompt context for the AI agent.

## 2. Verify a translation spec

    # specs/fact.json declares lua + c variants of fact()
    python pipeline.py specs/fact.json

    == pipeline: fact cross-language ==
      [lua] specs/fact.lua: 2 paths
      [c] specs/fact.c: 2 paths
      [lua] contract:
          ['(n = 0)'] -> 1
          ['(not (n = 0))'] -> n * fact(n - 1)
      [c] contract:
          ['(n = 0)'] -> 1
          ['(not (n = 0))'] -> n * fact(n - 1)
      idiom[lua] if-return-else-return -> ternary: return n == 0 ? 1 : n * fact(n - 1);
      artifact: specs/fact.ternary.c
    POSTPROCESS invariants hold -- certificate issued

## 3. Query the service (any client language)

    $ python service.py
    {"method": "parse", "params": {"language": "go", "source": "func f(n int) int {\n\tif n > 0 {\n\t\treturn n\n\t}\n\treturn -n\n}"}}
    {"ok": true, "ast": {"tag": "source_file", ...}}

    {"method": "contracts", "params": {"language": "rust", "source": "fn absval(n: i32) -> i32 {\n    if n > 0 {\n        return n;\n    }\n    -n\n}"}}
    {"ok": true, "contract": [[["(n > 0)"], "n"], [["(not (n > 0))"], "-n"]]}

    {"method": "verify", "params": {"spec": "specs/fact.json"}}
    {"ok": true, "certificate": true, "name": "fact cross-language", "log": "..."}

## 4. Run the certificates

    python m9_trifecta.py     # Python/Go/Rust identical constraints (real tree-sitter)
    python m10_complex.py     # loops + state + closed forms
    python m6_emit.py         # Lua -> C rewrite, gcc-verified at runtime
    python run_tests.py       # 51 tests

## 5. The closed TDD loop

    agent writes code
        -> POST source to service (method: parse + contracts)
        <- AgentReport JSON: violations[], paths[] with per-path constraints
    agent rewrites until violations == [] and all paths satisfiable
        -> iterate; the report is diffable across iterations
