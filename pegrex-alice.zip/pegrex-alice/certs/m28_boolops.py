#!/usr/bin/env python
"""M28 -- short-circuit booleans: `or`/`and` in conditions become
And/Or constraint trees (the cond atom already splits on `and`; `or` now too)."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator
from pegrex.sym import And as SAnd, Or as SOr

SRC = """def f(a, b):
    if a > 0 or b < 10:
        return 1
    return 0
"""
parse, tagspec, make_cond = pipeline.python_frontend()
body = parse(SRC)
cfg = CFGBuilder(tagspec).build(body)
cond = make_cond(SRC)
cons = set()
for p in PathEnumerator(cfg, unroll=1).enumerate():
    for i in range(len(p) - 1):
        for dst, e in cfg.successors(p[i]):
            if dst == p[i + 1] and e.cond is not None:
                base = e.cond[0] if isinstance(e.cond, tuple) else e.cond
                cons.add(str(cond(base)))
print("constraints:", sorted(cons))
assert any("or" in c for c in cons), cons
print("M28 CERTIFICATE: short-circuit or -> Or-tree constraint")
