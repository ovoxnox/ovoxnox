#!/usr/bin/env python
"""M68 -- CI/CD security: GitHub Actions anti-patterns detected."""
import pathlib, sys, tempfile
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.ci import analyze_pipeline

WORKFLOW = """name: ci
on:
  pull_request_target:
    types: [opened]
jobs:
  test:
    runs-on: ubuntu-latest
    permissions: write-all
    steps:
      - uses: actions/checkout@v4
      - name: setup
        run: curl https://example.com/install.sh | bash
      - env:
          API_KEY: "abcdef1234567890abcdef1234567890"
        run: make test
"""
f = tempfile.NamedTemporaryFile("w", suffix=".yml", delete=False)
f.write(WORKFLOW)
f.close()
findings = analyze_pipeline(f.name)
for x in findings:
    print(f"  {x['severity']:9} {x['id']:26} L{x['line']}")
ids = {x["id"] for x in findings}
assert "ci-pr-target-checkout" in ids
assert "ci-unpinned-action" in ids
assert "ci-hardcoded-secret" in ids
assert "ci-excessive-permissions" in ids
assert "ci-curl-pipe-shell" in ids
print("M68 CERTIFICATE: all 5 CI anti-pattern classes detected")
