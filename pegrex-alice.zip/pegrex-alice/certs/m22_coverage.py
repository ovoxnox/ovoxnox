#!/usr/bin/env python
"""M22 -- constraint-aware path coverage: a synthetic LCOV where the
recursive branch of fact() was never tested -> the gap arrives WITH its
constraint context."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.coverage import (coverage_gaps, covered_lines, parse_lcov,
                             path_coverage)

SRC = pathlib.Path("specs/fact.py").read_text()
# synthetic LCOV: only the base-case line covered (the recursion untested)
base_line = next(i for i, l in enumerate(SRC.splitlines(), 1)
                 if "return 1" in l)
LCOV = f"""SF:specs/fact.py
DA:{base_line},1
DA:{base_line + 2},0
end_of_record
"""
cov = parse_lcov(LCOV)["specs/fact.py"]
cov_lines = covered_lines(cov)

parse, tagspec, make_cond = pipeline.python_frontend()
body = parse(SRC)
cfg = CFGBuilder(tagspec).build(body)
from pegrex.paths import PathEnumerator
paths = PathEnumerator(cfg, unroll=1).enumerate()
overlay = path_coverage(cfg, paths, cov_lines)
print(f"paths: {len(paths)}, fully covered: "
      f"{sum(1 for o in overlay if o['covered'])}/{len(overlay)}")

gaps = coverage_gaps(cfg, make_cond(SRC), cov_lines)
print("gaps:")
for g in gaps:
    print(f"  constraints={g['constraints']} uncovered={g['uncovered_blocks']}")
assert gaps and any("not" in c for g in gaps for c in g["constraints"])
print("M22 CERTIFICATE: coverage gap carries its constraint context")
