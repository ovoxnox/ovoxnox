#!/usr/bin/env python
"""M29 -- recursion analysis: bounded vs unbounded recursion detection."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.recursion import analyze_recursion

BOUNDED = """def fact(n):
    if n == 0:
        return 1
    return n * fact(n - 1)
"""
UNBOUNDED = """def loop(n):
    return loop(n - 1)
"""
parse, _, _ = pipeline.python_frontend()
r1 = analyze_recursion("fact", parse(BOUNDED), BOUNDED)
r2 = analyze_recursion("loop", parse(UNBOUNDED), UNBOUNDED)
print(f"fact: recursive={r1.is_recursive} base={r1.has_base_case} "
      f"unbounded={r1.unbounded}")
print(f"loop: recursive={r2.is_recursive} base={r2.has_base_case} "
      f"unbounded={r2.unbounded}")
assert r1.is_recursive and r1.has_base_case and not r1.unbounded
assert r2.is_recursive and not r2.has_base_case and r2.unbounded
print("M29 CERTIFICATE: recursion bounded/unbounded classified")
