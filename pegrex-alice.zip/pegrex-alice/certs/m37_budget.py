#!/usr/bin/env python
"""M37 -- complexity budgets: gates that fail when modules grow."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from pegrex.budget import Budget

# compiler.py exceeds the default budget -> gate fails
big = pathlib.Path("pegrex/compiler.py").read_text()
b = Budget(max_loc=300)
b.check("pegrex/compiler.py", big,
        fn_lines={"compile": 60}, doc_ratio=0.3)
print("compiler.py gate:", "PASS" if b.passed else "FAIL")
for f in b.findings:
    print("  ", f)
assert not b.passed

# a small module passes
small = pathlib.Path("specs/fact.py").read_text()
b2 = Budget(max_loc=300, max_function_lines=40)
b2.check("specs/fact.py", small, fn_lines={"fact": 6})
print("fact.py gate:", "PASS" if b2.passed else "FAIL")
assert b2.passed
print("M37 CERTIFICATE: budget gate fails big modules, passes small")
