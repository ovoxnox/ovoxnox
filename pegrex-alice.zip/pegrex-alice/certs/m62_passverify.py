#!/usr/bin/env python
"""M62_PASSVERIFY -- see title."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.passverify import verify_pass
from pegrex.sym import V, const, Gt
src = "def f(n):\n    if n > 0:\n        return 1\n    return 0\n"
parse, tags, mk = pipeline.python_frontend()
cfg1 = CFGBuilder(tags).build(parse(src))
cfg2 = CFGBuilder(tags).build(parse(src))   # identity 'optimization'
cond = lambda node: Gt(V("n"), const(0))
render = lambda st: "1"
assert verify_pass(cfg1, cfg2, cond, render)
print("M62 CERTIFICATE: identity pass verified bisimilar")
