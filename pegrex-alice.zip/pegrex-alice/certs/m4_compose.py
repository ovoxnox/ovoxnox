#!/usr/bin/env python
"""M4 -- modular composition: caller contracts expanded through callee
contracts, compared across languages.

  Lua: clamp(x) = x<0 and 0 or x ; f(n) = clamp(n) + 1
  C:   clamp(int x) { if/else }  ; g(int n) { return clamp(n) + 1; }

The composed contract of f/g (clamp inlined via its contract, not its
body) must be identical across languages.
"""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.peg import Node
from pegrex.cfg import CFGBuilder
from pegrex.summaries import render_lua, render_c, path_summaries, compose

ROOT = pathlib.Path(__file__).parent.parent

PY_SRC = 'def clamp(x):\n    if x < 0:\n        return 0\n    return x\n\ndef f(n):\n    return clamp(n) + 1\n'

import pipeline
_lf = pipeline.python_frontend()
_parse, tagspec, make_cond = _lf
bodies = pipeline.python_functions(PY_SRC)


def ts_render(st, src=PY_SRC):
    t = st.children[0] if st.children and isinstance(st.children[0], str) \
        else src[st.pos:st.endpos]
    return t.replace("return", "").strip()


clamp_lua = path_summaries(CFGBuilder(tagspec).build(bodies["clamp"]),
                           make_cond(PY_SRC), ts_render)
f_lua = path_summaries(CFGBuilder(tagspec).build(bodies["f"]),
                       make_cond(PY_SRC), ts_render)


# ---- C
C_SRC = """int clamp(int x) {
  if (x < 0) { return 0; } else { return x; }
}
int g(int n) {
  return clamp(n) + 1;
}
"""
parse_c, tagspec_c, make_cond_c = pipeline.c_frontend()
src_c = (ROOT / "examples" / "c11.gram").read_text()
cast = pipeline.c_parse_full(C_SRC)
assert cast is not None
def find_all(x, tag, acc):
    if isinstance(x, Node):
        if x.tag == tag: acc.append(x)
        for c in x.children: find_all(c, tag, acc)
    elif isinstance(x, list):
        for c in x: find_all(c, tag, acc)
    return acc
bodies = find_all(cast, "compound-statement", [])
# DFS order: clamp body first, its if-branch compounds next, g body last
clamp_body, g_body = bodies[0], bodies[-1]
clamp_c = path_summaries(CFGBuilder(tagspec_c).build(clamp_body),
                         make_cond_c(C_SRC), lambda st: render_c(st, C_SRC))
g_c = path_summaries(CFGBuilder(tagspec_c).build(g_body),
                     make_cond_c(C_SRC), lambda st: render_c(st, C_SRC))

print("clamp (lua):", [(sorted(c), r) for c, r in clamp_lua])
print("clamp (c):  ", [(sorted(c), r) for c, r in clamp_c])
assert clamp_lua == clamp_c, "callee contracts differ"

composed_lua = compose(f_lua, "clamp", clamp_lua, param="x", arg="n")
composed_c = compose(g_c, "clamp", clamp_c, param="x", arg="n")
print("\ncomposed f (lua):")
for cons, res in composed_lua:
    print(f"  {sorted(cons)} -> {res}")
print("composed g (c):")
for cons, res in composed_c:
    print(f"  {sorted(cons)} -> {res}")

assert composed_lua == composed_c, "composed contracts differ across languages"
print("\nM4 CERTIFICATE: modular composition identical across languages")
