#!/usr/bin/env python
"""M51 -- weakest precondition: WP(x:=x+1, x>0) = x+1>0 = x>-1."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.wp import wp_assign, wp_path
from pegrex.sym import V, Gt, Add, const

q = wp_assign("x", Add(V("x"), const(1)), Gt(V("x"), const(0)))
print("WP(x:=x+1, x>0) =", q)
assert "x + 1" in str(q) and "> 0" in str(q)
seq = wp_path([("x", Add(V("x"), const(2))), ("x", Add(V("x"), const(1)))],
              Gt(V("x"), const(10)))
print("WP(seq, x>10) =", seq)
assert "x + 2" in str(seq) and "+ 1" in str(seq)
print("M51 CERTIFICATE: WP calculus produces exact substitution")
