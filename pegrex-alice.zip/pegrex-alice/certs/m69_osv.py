#!/usr/bin/env python
"""M69 -- OSV scanning: inventory + cached queries (offline-safe)."""
import pathlib, sys, tempfile, json
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.sca import inventory_from, scan

lockdir = pathlib.Path(tempfile.mkdtemp())
lockfile = lockdir / "package-lock.json"
lockfile.write_text(json.dumps({"packages": {
    "node_modules/lodash": {"version": "4.17.15"}}}))
deps = inventory_from(str(lockfile))
print("inventory:", deps)
assert deps and deps[0]["ecosystem"] == "npm"
out = scan(str(lockfile))   # may be offline -> inventory only, must not crash
print("scan:", out["dependencies"], "deps,",
      len(out["vulnerabilities"]), "vulns, offline:", out["offline"])
print("M69 CERTIFICATE: OSV scan inventory + cache, offline-safe")
