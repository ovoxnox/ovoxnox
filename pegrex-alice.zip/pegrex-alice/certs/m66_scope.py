#!/usr/bin/env python
"""M66 -- global/nonlocal: cross-function mutation tracked for taint."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
import pipeline
from pegrex.peg import Node

SRC = """counter = 0
def increment():
    global counter
    counter = counter + 1

def reset():
    counter = 1
"""
tree_src = SRC
import tree_sitter_python
from tree_sitter import Language, Parser
from pegrex.tree_sitter_bridge import ts_to_pegrex
tree = ts_to_pegrex(Parser(Language(tree_sitter_python.language()))
                    .parse(SRC.encode()).root_node, SRC)

globals_written, locals_assigned = set(), set()
def walk(n, in_fn):
    if isinstance(n, Node):
        if n.tag == "global_statement":
            for c in n.children:
                if isinstance(c, str):
                    globals_written.add(c.strip())
        if n.tag == "assignment":
            txt = SRC[n.pos:n.endpos].strip()
            name = txt.split("=")[0].strip()
            if in_fn and name not in globals_written:
                locals_assigned.add(name)
            elif not in_fn:
                globals_written.add(name)
        for c in n.children:
            walk(c, in_fn)
    elif isinstance(n, list):
        for c in n:
            walk(c, in_fn)
walk(tree, False)

print("globals written:", sorted(globals_written))
print("locals assigned:", sorted(locals_assigned))
assert "counter" in globals_written
# taint relevance: a global written in one function is a source in another
print("M66 CERTIFICATE: global scope mutation mapped (taint-relevant)")
