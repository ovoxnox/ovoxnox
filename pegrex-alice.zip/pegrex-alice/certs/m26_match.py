#!/usr/bin/env python
"""M26 -- match/switch: multi-way branches through the CFG."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator

PY = """def grade(score):
    match score:
        case 90:
            return "A"
        case 80:
            return "B"
        case _:
            return "F"
"""
parse, tagspec, make_cond = pipeline.python_frontend()
body = parse(PY)
cfg = CFGBuilder(tagspec).build(body)
arm_edges = [e for e in cfg.edges if e.kind == "arm"]
print(f"arm edges: {len(arm_edges)}")
assert len(arm_edges) == 3, len(arm_edges)
paths = PathEnumerator(cfg, unroll=1).enumerate()
assert len(paths) == 3, paths
print("M26 CERTIFICATE: match statement -> 3 arm edges, 3 paths")
