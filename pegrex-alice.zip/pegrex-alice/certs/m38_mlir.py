#!/usr/bin/env python
"""M38 -- MLIR frontend: cf.cond_br branches into the CFG (hivm-spec corpus shape)."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.paths import PathEnumerator

MLIR = """module {
  func.func @f(%n: i32) -> i32 {
    %c0 = arith.constant 0 : i32
    %cond = arith.cmpi slt, %n, %c0 : i32
    cf.cond_br %cond, ^neg, ^pos
  ^neg:
    %r = arith.subi %c0, %n : i32
    return %r : i32
  ^pos:
    return %n : i32
  }
}
"""
_, cfg_from_mlir, _ = pipeline.mlir_frontend()
cfg = cfg_from_mlir(MLIR)
print("blocks:", len(cfg.blocks), "edges:", [(e.src, e.dst, e.kind) for e in cfg.edges])
paths = PathEnumerator(cfg, unroll=1).enumerate()
print("M38 CERTIFICATE: MLIR cf.cond_br ->", len(paths), "path(s) through the CFG")
