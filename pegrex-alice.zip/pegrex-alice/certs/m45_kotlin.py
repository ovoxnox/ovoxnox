#!/usr/bin/env python
"""M45 -- Kotlin: if-expression paths through the CFG."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator

parse, tags, mk = pipeline.kotlin_frontend()
cfg = CFGBuilder(tags).build(parse(
    "fun classify(n: Int): Int { if (n > 0) { return 1 } return 0 }"))
paths = PathEnumerator(cfg, unroll=1).enumerate()
print(f"kotlin: {len(paths)} paths")
assert len(paths) == 2
print("M45 CERTIFICATE: Kotlin if-expression -> 2 paths")
