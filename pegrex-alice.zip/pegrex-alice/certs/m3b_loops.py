#!/usr/bin/env python
"""M3b -- loop case: sum 1..n in Lua and C.  Exercises back edges."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from m3_crosslang import (compile_grammar, peg, pegrex, Node, CFGBuilder, TagSpec,
                          PathEnumerator, V, const, Eq, Not, Lt, Le, Gt, Ge, OPS,
                          lua_operand, c_operand, c_cond, constraints, ROOT)

PY_SUM = """def sum(n):
    s = 0
    i = 1
    while i <= n:
        s = s + i
        i = i + 1
    return s
"""
C_SUM = """int sum(int n) {
  int s = 0;
  int i = 1;
  while (i <= n) {
    s = s + i;
    i = i + 1;
  }
  return s;
}
"""

import pipeline
_parse, tagspec, make_cond = pipeline.python_frontend()
lua_body = _parse(PY_SUM)

typedefs = set()
def is_typedef(s, pos, node): return node.children[0] in typedefs
def set_typedef(s, pos, *caps):
    node = next((c for c in caps if isinstance(c, pegrex.Node)), None)
    d = node
    while d is not None and d.tag != "identifier":
        kids = [k for k in getattr(d, "children", []) if isinstance(k, pegrex.Node)]
        d = kids[0] if kids else None
    if d is not None: typedefs.add(d.children[0])
    return True
cdefs = {"is_typedef": is_typedef, "set_typedef": set_typedef}
c_gram = (ROOT / "examples" / "c11.gram").read_text()
cstart, crules = compile_grammar(c_gram, defs=cdefs)
cast, cerr, _ = peg.run(cstart, C_SUM, crules, defs=cdefs)
assert cerr is None, cerr

def first_node(x, tag):
    if isinstance(x, Node):
        if x.tag == tag: return x
        for c in x.children:
            r = first_node(c, tag)
            if r is not None: return r
    elif isinstance(x, list):
        for c in x:
            r = first_node(c, tag)
            if r is not None: return r
    return None

c_body = first_node(cast, "compound-statement")
assert c_body is not None

# C iteration-statement (while form): raw children mix strings and nodes
# (plain-rule expression flattens its captures).  Body = last Node child;
# condition = everything before it.
def c_while(ch):
    nodes = [c for c in ch if isinstance(c, Node)]
    body = nodes[-1]
    return (ch[:ch.index(body)], body)

lua_cfg = CFGBuilder(tagspec).build(lua_body)
c_while._tag = "iteration-statement"
c_cfg = CFGBuilder(TagSpec(if_="selection-statement", while_=c_while,
                           block="compound-statement", return_="jump-statement")).build(c_body)

def lua_cond(node):
    txt = (node.children[0] if node.children and
           isinstance(node.children[0], str)
           else PY_SUM[node.pos:node.endpos])
    m = __import__("re").match(
        r"\s*([A-Za-z_]\w*)\s*(<=|>=|<|>|==|!=)\s*(-?\d+|[A-Za-z_]\w*)", txt.strip())
    a, b = m.group(1), m.group(3)
    av = V(a) if not a.lstrip("-").isdigit() else const(int(a))
    bv = V(b) if not b.lstrip("-").isdigit() else const(int(b))
    return OPS[m.group(2)](av, bv)

lua_cons = constraints(lua_cfg, lua_cond)
c_cons = constraints(c_cfg, lambda n: c_cond(n, C_SUM))
print(f"Lua paths (unroll=1): {len(lua_cons)}")
for c in lua_cons: print("  ", sorted(c))
print(f"C paths (unroll=1):   {len(c_cons)}")
for c in c_cons: print("  ", sorted(c))

# loop-free path (i>n immediately): identical; one-iteration paths identical
assert len(lua_cons) == len(c_cons)
assert lua_cons == c_cons, "loop path formulas differ"
print()
print("M3b CERTIFICATE: while-loop path constraints identical across languages")
