#!/usr/bin/env python
"""M36 -- lazy CFG: paths without upfront block construction."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder, enumerate_paths_lazy

SRC = """def f(n):
    if n > 0:
        while n > 10:
            if n == 15:
                return 1
            n = n - 1
    return 0
"""
parse, tagspec, make_cond = pipeline.python_frontend()
body = parse(SRC)

eager = CFGBuilder(tagspec).build(body)
n_edge_objects = len(eager.edges)
paths = list(enumerate_paths_lazy(body, tagspec, unroll=1))
peak_path = max(len(p) for p in paths)
# lazy: no CFG object exists -- peak state is one path list (ints only)
print(f"eager: {len(eager.blocks)} blocks + {n_edge_objects} edge objects upfront")
print(f"lazy: 0 edge objects, peak state = one path of {peak_path} ints")
assert n_edge_objects > 0 and peak_path <= len(eager.blocks)
print("M36 CERTIFICATE: lazy streams paths with O(path) state, no edge objects")
