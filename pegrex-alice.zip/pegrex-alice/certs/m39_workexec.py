#!/usr/bin/env python
"""M39 -- .work agents execute: workflow steps run through engine executors."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from pegrex.workexec import execute

out = execute("examples/quality.work", "/mnt/agents/upload/codepaths.py")
print("agent:", out["agent"])
for step, res in out["steps"].items():
    print(f"  {step}: {res}")
assert out["steps"]["detect_anomaly"]["findings"] > 0
assert out["steps"]["collect_data"]["contract_paths"] >= 1
assert out["steps"]["write_report"]["perplexity"] > 0
print("M39 CERTIFICATE: .work agent executed end-to-end on the engine")
