#!/usr/bin/env python
"""M3 -- cross-language path-constraint certificate.

fact.lua and fact.c are idiomatically different source texts.  Both parse
to pegrex Node trees; both lower to CFGs; every execution path projects to
a mathematical formula (path constraints).  If the formulas match, the
translations are behaviorally equivalent -- the core of the
'meta-projection of idioms' thesis.
"""
import pathlib, re, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pegrex
from pegrex import compile_grammar, peg
from pegrex.peg import Node
from pegrex.cfg import CFGBuilder, TagSpec
from pegrex.paths import PathEnumerator
from pegrex.sym import Op, Sym, V, const, Eq, Not, Lt, Le, Gt, Ge

ROOT = pathlib.Path(__file__).parent.parent

# ---------------------------------------------------------------- sources
PY_FACT = "def fact(n):\n    if n == 0:\n        return 1\n    return n * fact(n - 1)\n"
C_FACT = """int fact(int n) {
  if (n == 0) {
    return 1;
  } else {
    return n * fact(n - 1);
  }
}
"""

# --------------------------------------------------------- parse (Python)
import pipeline
_parse, tagspec, make_cond = pipeline.python_frontend()
lua_body = _parse(PY_FACT)               # first function body (tree-sitter)

# --------------------------------------------------------- parse (C)
c_gram = (ROOT / "examples" / "c11.gram").read_text()
typedefs = set()
def is_typedef(s, pos, node): return node.children[0] in typedefs
def set_typedef(s, pos, *caps):
    node = next((c for c in caps if isinstance(c, pegrex.Node)), None)
    d = node
    while d is not None and d.tag != "identifier":
        kids = [k for k in getattr(d, "children", []) if isinstance(k, pegrex.Node)]
        d = kids[0] if kids else None
    if d is not None: typedefs.add(d.children[0])
    return True
cdefs = {"is_typedef": is_typedef, "set_typedef": set_typedef}
cstart, crules = compile_grammar(c_gram, defs=cdefs)
cast, cerr, _ = peg.run(cstart, C_FACT, crules, defs=cdefs)
assert cerr is None, cerr
# function-definition caps: [declaration-specifiers, declarator, compound]
def first_node(x, tag):
    if isinstance(x, Node):
        if x.tag == tag: return x
        for c in x.children:
            r = first_node(c, tag)
            if r is not None: return r
    elif isinstance(x, list):
        for c in x:
            r = first_node(c, tag)
            if r is not None: return r
    return None
c_body = None
for item in (cast if isinstance(cast, list) else [cast]):
    if isinstance(item, Node) and item.tag == "compound-statement":
        c_body = item
assert c_body is not None

# ------------------------------------------------- condition translators
OPS = {"eq": Eq, "==": Eq, "lt": Lt, "<": Lt, "le": Le, "<=": Le,
       "gt": Gt, ">": Gt, "ge": Ge, ">=": Ge,
       "ne": lambda a, b: Not(Eq(a, b)), "~=": lambda a, b: Not(Eq(a, b)),
       "!=": lambda a, b: Not(Eq(a, b))}

def lua_operand(x):
    if isinstance(x, Node):
        if x.tag == "Id":    return V(x.children[0])
        if x.tag == "Number": return const(x.children[0])
    return const(x)

def lua_cond(node):
    txt = (node.children[0] if node.children and
           isinstance(node.children[0], str)
           else PY_FACT[node.pos:node.endpos])
    m = re.match(r"\s*([A-Za-z_]\w*)\s*(<=|>=|<|>|==|!=)\s*(-?\d+|[A-Za-z_]\w*)", txt.strip())
    a, b = m.group(1), m.group(3)
    av = V(a) if not a.lstrip("-").isdigit() else const(int(a))
    bv = V(b) if not b.lstrip("-").isdigit() else const(int(b))
    return OPS[m.group(2)](av, bv)

def c_operand(x):
    if isinstance(x, Node):
        if x.tag == "identifier": return V(x.children[0])
    if isinstance(x, str):
        try: return const(int(x, 0))
        except ValueError: return V(x)
    return const(x)

def c_cond(node, src):
    if isinstance(node, list) and len(node) == 1 and isinstance(node[0], Node):
        return c_cond(node[0], src)     # singleton wrapper from while_parts
    ch = node if isinstance(node, list) else \
        [c for c in node.children if isinstance(c, (Node, str))]
    tag = None if isinstance(node, list) else node.tag
    if (tag in ("binary-expression", "conditional-expression") or tag is None) and len(ch) >= 3:
        a, opn, b = ch[0], ch[1], ch[2]
        op = src[opn.pos:opn.endpos].strip() if isinstance(opn, Node) else str(opn)
        return OPS[op](c_operand(a), c_operand(b))
    if tag == "identifier":
        return V(node.children[0])
    raise ValueError(f"cannot translate C condition: {node!r}")

# ----------------------------------------------------------- build CFGs
lua_cfg = CFGBuilder(tagspec).build(lua_body)
c_cfg = CFGBuilder(TagSpec(if_="selection-statement", while_="iteration-statement",
                           block="compound-statement", return_="jump-statement")).build(c_body)
print("Lua CFG:"); print(lua_cfg.to_dot()); print()
print("C CFG:"); print(c_cfg.to_dot()); print()

# ------------------------------------------------ path constraint sets
def constraints(cfg, translator):
    out = []
    for path in PathEnumerator(cfg, unroll=1).enumerate():
        cons = []
        for i in range(len(path) - 1):
            for dst, e in cfg.successors(path[i]):
                if dst != path[i + 1] or e.cond is None:
                    continue
                if e.kind in ("then", "body"):
                    cons.append(translator(e.cond))
                elif e.kind in ("else", "exit"):
                    base = e.cond[0] if isinstance(e.cond, tuple) else e.cond
                    cons.append(Not(translator(base)))
        out.append(frozenset(str(c) for c in cons))
    return sorted(out, key=str)

lua_cons = constraints(lua_cfg, lua_cond)
c_cons = constraints(c_cfg, lambda n: c_cond(n, C_FACT))
print("Lua path constraints:", lua_cons)
print("C path constraints:  ", c_cons)

assert len(lua_cons) == len(c_cons) == 2
assert lua_cons == c_cons, "path formulas differ across languages!"
print()
print("M3 CERTIFICATE: fact.lua and fact.c have identical path-constraint sets")
print("-- behaviorally equivalent under the meta-projection --")
