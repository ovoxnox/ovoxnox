#!/usr/bin/env python
"""M17 -- exception flow: try/except paths through the CFG."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator

SRC = """def parse(data):
    try:
        value = int(data)
    except ValueError:
        value = -1
    return value
"""
parse_fn, tagspec, make_cond = pipeline.python_frontend()
body = parse_fn(SRC)
cfg = CFGBuilder(tagspec).build(body)
kinds = sorted({e.kind for e in cfg.edges})
print("edge kinds:", kinds)
assert "raise" in kinds and "noexcept" in kinds
paths = PathEnumerator(cfg, unroll=1).enumerate()
print(f"paths: {len(paths)}")
assert len(paths) == 2, paths
print("M17 CERTIFICATE: try/except -> normal + exception path")
