#!/usr/bin/env python
"""M20 -- grammar induction: s-expressions from examples."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from pegrex.induce import fitness, induce

POS = ["(add 1 2)", "(sub (mul 3 4) 5)", "(x)", "(f 1 (g 2))"]
NEG = ["add 1", "(add 1", "((", "(1 2"]
HELD = ["(h 7 (i 8))", "(single)"]          # generalization check

SEED = """START <- .+
CHAR  <- [a-z]
SKIP  <- %s*
"""
best, score = induce(POS, NEG, SEED)
print("score:", score, f"({len(POS)} pos / {len(NEG)} neg)")
print("induced grammar:")
print(best)
assert score[0] == len(POS), "positives not all accepted"
gen = fitness(best, HELD, [])[0]
print("generalization:", gen, "/", len(HELD))
assert gen == len(HELD)
print("M20 CERTIFICATE: grammar induced from examples, generalizes")
