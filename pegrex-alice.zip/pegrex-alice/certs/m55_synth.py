#!/usr/bin/env python
"""M55 -- synthesis: constraints -> candidate programs."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.synthesize import synthesize

cands = synthesize(["(n > 0)", "(n <= 10)"], vars=("n",), consts=(1, 5),
                   limit=5)
print("candidates:", cands[:5])
assert len(cands) >= 3
print("M55 CERTIFICATE: constraint-satisfying programs enumerated")
