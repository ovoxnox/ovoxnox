#!/usr/bin/env python
"""M8 -- AI-targeted spec generation (the debugging interface).

Full architectural pipeline over a Python function:

  tree-sitter-shaped AST -> native pattern guardrails -> CFG -> SSA ->
  path constraints -> solver evaluation -> AgentReport JSON schema.

The report is engineered for AI-agent prompt context: violations,
per-path constraint boundaries, satisfiability, SSA versions.
"""
import pathlib, re, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from pegrex.patterns import Pattern
from pegrex.tree_sitter_bridge import ts_to_pegrex, TAGSPECS
from pegrex.specgen import analyze
from pegrex.formulas import V, const, Eq, Lt, Le, Gt, Ge, Not, OPS_TXT


class TS:  # minimal tree-sitter node shape
    def __init__(self, type_, children=(), text=None, named=True, s=0, e=0):
        self.type, self.children = type_, list(children)
        self.text, self.is_named = text, named
        self.start_byte, self.end_byte, self.child_count = s, e, len(self.children)


SRC = "def absval(n):\n  if n > 0:\n    return n\n  return -n"
PY = TS("module", [TS("function_definition", [
    TS("identifier", text="absval", s=4, e=10),
    TS("parameters", [TS("identifier", text="n")]),
    TS("block", [
        TS("if_statement", [
            TS("condition", s=20, e=25),
            TS("block", [
                TS("return_statement", [TS("identifier", text="n")],
                   s=27, e=38),
            ]),
            TS("block", [
                TS("return_statement", [TS("unary", text="-n")],
                   s=40, e=50),
            ]),
        ]),
    ]),
], s=0, e=200)])

tree = ts_to_pegrex(PY, SRC)


def cond(node):
    txt = getattr(node, "text", None)
    if not txt and node.children and isinstance(node.children[0], str):
        txt = node.children[0]          # leaf text preserved by the bridge
    m = re.match(r"\s*([A-Za-z_]\w*)\s*(<=|>=|<|>|==|!=)\s*(-?\d+)", txt or "")
    op = {"<": Lt, "<=": Le, ">": Gt, ">=": Ge, "==": Eq, "!=": lambda a, b: Not(Eq(a, b))}
    return op[m.group(2)](V(m.group(1)), const(int(m.group(3))))


def render(st, src=None):
    t = getattr(st, "text", None)
    if not t and getattr(st, "children", None) and isinstance(st.children[0], str):
        t = st.children[0]
    return (t or "").replace("return", "").strip()


rules = [
    Pattern(node_type="condition", text=r"n\s*==\s*None", id="eq-none-anti-pattern"),
    Pattern(node_type="return_statement", text=r"return\s+-", id="negated-return"),
]

SRC = "def absval(n):\n  if n > 0:\n    return n\n  return -n"
report = analyze(tree, "python", "absval", rules=rules,
                 tagspec=TAGSPECS["python"], src=SRC, cond=cond, render=render)
print(report.to_agent_json())

assert len(report.paths) == 2
assert all(p.satisfiable for p in report.paths)
vids = [v.rule_id for v in report.syntactic_violations]
assert "negated-return" in vids and "eq-none-anti-pattern" not in vids
assert report.z3["paths_satisfiable"] == 2
print()
print("M8 OK: AgentReport generated -- AI-agent debugging interface ready")
