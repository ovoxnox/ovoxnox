#!/usr/bin/env python
"""M25 -- cross-file contracts: caller in one file, callee in another."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.summaries import path_summaries, compose

# callee lives in specs/chain.py (clamp); caller here
CALLER = """def bump(n):
    return clamp(n) + 1
"""
c_parse, c_tags, c_cond = pipeline.python_frontend()
callee_src = pathlib.Path("specs/chain.py").read_text()
callees = pipeline.python_functions(callee_src)
callee = path_summaries(CFGBuilder(c_tags).build(callees["clamp"]),
                        c_cond(callee_src),
                        lambda st: (callee_src[st.pos:st.endpos]
                                    ).replace("return", "").strip())
parse, tags, cond = pipeline.python_frontend()
caller = path_summaries(CFGBuilder(tags).build(parse(CALLER)),
                        cond(CALLER),
                        lambda st: (CALLER[st.pos:st.endpos]
                                    ).replace("return", "").strip())
out = compose(caller, "clamp", callee, param="x", arg="n")
print("cross-file contract:", out)
assert len(out) == 2
print("M25 CERTIFICATE: cross-file modular composition")
