#!/usr/bin/env python
"""M14 -- the mini LLM: trained on the project's own sources, it generates
plausible token-kind sequences and scores held-out code by perplexity."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from pegrex.mini_llm import NGramLM

ROOT = pathlib.Path(__file__).parent.parent
corpus = "".join(p.read_text() for p in (ROOT / "specs").glob("*.py"))
lm = NGramLM(n=3)
lm.train(corpus)

gen = lm.generate("def fact", 15)
print("generate:", gen)
p_train = lm.perplexity(corpus[:200])
p_garbage = lm.perplexity("class 123 ~~~ ???")
print(f"perplexity(project code): {p_train:.2f}")
print(f"perplexity(garbage):      {p_garbage:.2f}")
assert p_garbage > p_train
print("M14 CERTIFICATE: the mini LLM prefers project code over noise")
