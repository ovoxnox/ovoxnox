#!/usr/bin/env python
"""M32 -- test synthesis: coverage gaps become ready-made tests."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.coverage import parse_lcov, covered_lines
from pegrex.testsynth import synthesize_tests

SRC = pathlib.Path("specs/fact.py").read_text()
base_line = next(i for i, l in enumerate(SRC.splitlines(), 1)
                 if "return 1" in l)
LCOV = f"SF:fact.py\nDA:{base_line},1\nDA:{base_line + 2},0\nend_of_record\n"
cov_lines = covered_lines(list(parse_lcov(LCOV).values())[0])

parse, tagspec, make_cond = pipeline.python_frontend()
cfg = CFGBuilder(tagspec).build(parse(SRC))
tests = synthesize_tests(cfg, make_cond(SRC), cov_lines, "fact")
for t in tests:
    print("constraints:", t.constraints)
    print("inputs:", t.inputs)
    print(t.test_body)
assert tests and any(t.inputs.get("n") != 0 for t in tests)
print("M32 CERTIFICATE: gap -> synthesized test with concrete input")
