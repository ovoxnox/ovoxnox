#!/usr/bin/env python
"""M31 -- async/await: coroutines lower through the CFG."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator

SRC = """async def fetch(url):
    if url:
        data = await get(url)
        return data
    return None
"""
parse, tagspec, make_cond = pipeline.python_frontend()
body = parse(SRC)
cfg = CFGBuilder(tagspec).build(body)
awaits = sum(1 for b in cfg.blocks for s in b.stmts
             if "await" in (SRC[s.pos:s.endpos] if hasattr(s, "pos") else ""))
paths = PathEnumerator(cfg, unroll=1).enumerate()
print(f"await stmts: {awaits} | paths: {len(paths)}")
assert awaits == 1 and len(paths) == 2, (awaits, len(paths))
print("M31 CERTIFICATE: async/await -> CFG with", len(paths), "paths")
