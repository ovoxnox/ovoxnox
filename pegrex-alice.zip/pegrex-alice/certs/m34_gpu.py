#!/usr/bin/env python
"""M34 -- WebGPU host code: API sinks + render-loop path analysis."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator

JS = """async function render(device, ready) {
    if (!ready) {
        return null;
    }
    const buf = device.createBuffer({ size: 1024 });
    await buf.mapAsync(GPUMapMode.WRITE);
    device.queue.writeBuffer(buf, 0, data);
    return buf;
}
"""
parse, tagspec, make_cond = pipeline.javascript_frontend()
body = parse(JS)
cfg = CFGBuilder(tagspec).build(body)
paths = PathEnumerator(cfg, unroll=1).enumerate()
print("render-loop paths:", len(paths))
assert len(paths) == 2

# the GPU sink pack flags the host code
import subprocess as sp
pathlib.Path("/tmp/gpu.js").write_text(JS)
r = sp.run([sys.executable, "tools/secaudit.py", "/tmp/gpu.js"],
           cwd="/mnt/agents/output", capture_output=True, text=True)
gpu_hits = [l for l in r.stdout.splitlines() if l.startswith(("MEDIUM", "HIGH"))]
print("GPU findings:")
for l in gpu_hits[:4]:
    print("  ", l[:90])
assert any("mapAsync" in l or "writeBuffer" in l for l in gpu_hits)
print("M34 CERTIFICATE: WebGPU host code audited, render paths analyzed")
