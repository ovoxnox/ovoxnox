#!/usr/bin/env python
"""M59 -- legal DSL: clauses -> obligation constraints."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.legal import parse_clauses, obligations_as_constraints

clauses = parse_clauses("Buyer shall pay the price within 30 days. "
                        "Seller must deliver goods within 14 days.")
print("clauses:", clauses)
assert clauses[0]["party"] == "Buyer" and clauses[0]["deadline"] == 30
cons = obligations_as_constraints(clauses)
assert len(cons) == 2 and "30" in str(cons[0])
print("M59 CERTIFICATE: contract clauses formalized as constraints")
