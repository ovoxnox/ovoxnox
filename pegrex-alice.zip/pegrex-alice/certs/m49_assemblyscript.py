#!/usr/bin/env python
"""M49 -- AssemblyScript: parsed via the TypeScript frontend (AS is TS),
with WASM-specific rules. .ts extension already maps to javascript."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator

# AS is TS; the JS grammar parses AS constructs.  AS-only modifiers
# (export) and annotations (i32) surface as ERROR nodes in the JS grammar
# (documented) -- control flow is identical, so stripped syntax exercises
# the full pipeline; the WASM-rule scan below runs on raw AS source.
SRC = """function classify(n: number): number {   // export stripped:
  if (n > 0) {
    return 1;
  }
  return 0;
}
"""
parse, tags, mk = pipeline.javascript_frontend()
cfg = CFGBuilder(tags).build(parse(SRC))
paths = PathEnumerator(cfg, unroll=1).enumerate()
print(f"assemblyscript (via TS frontend): {len(paths)} paths")
assert len(paths) == 2

# WASM-specific rules on an AS-flavored sample
pathlib.Path("/tmp/vuln_as.ts").write_text("""export function unsafe(n: i32): void {
  const p = load<u8>(n);
  store<u8>(n, p + 1);
  env.log("done");
}
""")
import subprocess as sp
r = sp.run([sys.executable, "tools/secaudit.py", "/tmp/vuln_as.ts"],
           cwd="/mnt/agents/output", capture_output=True, text=True)
hits = [l for l in r.stdout.splitlines() if l.startswith(("HIGH", "MEDIUM"))]
print("AS rule hits:", len(hits))
for l in hits[:3]: print("  ", l[:80])
assert any("load" in l or "store" in l for l in hits)
print("M49 CERTIFICATE: AssemblyScript paths + WASM safety rules")
