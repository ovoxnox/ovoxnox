#!/usr/bin/env python
"""M40 -- induction benchmark: MLIR operation lines from examples (hivm-spec
L0 shape).  The induced grammar must accept all positives, reject negatives,
and generalize to held-out ops."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from pegrex.induce import fitness, induce

ROOT = pathlib.Path(__file__).parent.parent
pos = [l for l in (ROOT / "examples/bench-mlir/positives.txt")
       .read_text().splitlines() if l.strip()]
neg = [l for l in (ROOT / "examples/bench-mlir/negatives.txt")
       .read_text().splitlines() if l.strip()]
held = ["%z = arith.muli %x, %y : i32", "memref.dealloc %m : memref<2xf32>"]

SEED = """START <- .+
OP    <- [a-z.]+
"""
best, score = induce(pos, neg, SEED, rounds=80)
print("score:", score, f"({len(pos)} pos / {len(neg)} neg)")
print("generalization:", fitness(best, held, [])[0], "/", len(held))
assert score[0] == len(pos), "positives rejected"
assert score[1] >= len(neg) // 2, f"too few negatives rejected: {score[1]}"
print("negatives rejected:", score[1], "/", len(neg))
print("M40 CERTIFICATE: induction over the MLIR-op corpus")
