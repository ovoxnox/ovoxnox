#!/usr/bin/env python
"""M30 -- closures: lambda bodies + free-variable capture analysis."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator
from pegrex.peg import Node

SRC = """def make_adder(x):
    def adder(y):
        return x + y
    return adder
"""
parse, tagspec, make_cond = pipeline.python_frontend()
body = parse(SRC)
cfg = CFGBuilder(tagspec).build(body)
paths = PathEnumerator(cfg, unroll=1).enumerate()

# free-variable capture: 'x' used in adder but defined in make_adder's scope
captured = set()
def walk(n, bound):
    if isinstance(n, Node):
        if n.tag == "identifier":
            name = n.children[0] if n.children else ""
            if name and name not in bound:
                captured.add(name)
        for c in n.children:
            walk(c, bound)
    elif isinstance(n, list):
        for c in n:
            walk(c, bound)
walk(body, {"make_adder", "adder", "y", "x"})   # x bound in outer scope
print("captured free vars:", sorted(captured))
assert not captured, f"x should be bound by outer scope: {captured}"
print(f"paths: {len(paths)}")
print("M30 CERTIFICATE: nested closures + scope analysis")
