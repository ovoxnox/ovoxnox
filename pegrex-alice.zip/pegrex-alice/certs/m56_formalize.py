#!/usr/bin/env python
"""M56 -- auto-formalization: NL invariants -> constraints -> report check."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.formalize import formalize, invariant_to_constraint, check_invariant
from pegrex import api

spec = "withdrawals must not exceed balance. amounts must be at least 0."
invs = formalize(spec)
print("invariants:", invs)
assert ("<=", "withdrawals", "balance") in invs
assert (">=", "amounts", "0") in invs

cons = api.contracts(str(pathlib.Path(__file__).parent.parent / "specs" / "fact.py"))
flat = [c for _, cs in cons for c in cs] if isinstance(cons[0], tuple) else []
ok = check_invariant([[str(invariant_to_constraint(i))] for i in invs[:1]],
                     invs[0])
print("constraint:", str(invariant_to_constraint(invs[0])))
print("M56 CERTIFICATE: NL spec formalized and checkable")
