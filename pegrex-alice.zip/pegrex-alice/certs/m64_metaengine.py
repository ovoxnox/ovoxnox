#!/usr/bin/env python
"""M64_METAENGINE -- see title."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.metaengine import build_system
out = build_system(["%c0 = arith.constant 0 : i32", "%r = arith.addi %a, %b : i32"],
                   ["not mlir at all"], "START <- .+\n", domain="mlir")
print("tags:", out["tags"])
print("score:", out["score"])
assert out["tags"] and out["rule_skeletons"]
print("M64 CERTIFICATE: examples -> grammar -> tags -> rule skeletons")
