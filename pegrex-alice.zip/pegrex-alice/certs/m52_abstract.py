#!/usr/bin/env python
"""M52 -- abstract interpretation: intervals from path constraints."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.abstract import interval_analysis

iv = interval_analysis(["(n > 0)", "(n <= 100)"])
print("intervals:", iv)
assert iv["n"] == (0, 100) or iv["n"] == (1, 100)
iv2 = interval_analysis(["(x < 0)"])
assert iv2["x"][1] == 0 and iv2["x"][0] == float("-inf")
print("M52 CERTIFICATE: interval domain sound over constraints")
