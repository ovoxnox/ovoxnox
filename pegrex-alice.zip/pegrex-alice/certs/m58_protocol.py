#!/usr/bin/env python
"""M58 -- protocol: composed contracts satisfy the conservation invariant."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.protocol import verify_protocol

# transfer(amount): requires amount <= balance; conservation holds
caller = [(frozenset(), "transfer(n)")]
callee = [(frozenset({"(n <= 100)"}), "ok")]
out = verify_protocol(caller, {"transfer": callee}, {"transfer": "n"},
                      "(n <= 100)")
assert out["holds"] and out["paths"] >= 1
print("M58 CERTIFICATE: protocol invariant entailed on composed paths")
