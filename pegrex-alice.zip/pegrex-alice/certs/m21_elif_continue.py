#!/usr/bin/env python
"""M21 -- elif chains + continue: control-flow completeness."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator

SRC = """def classify(n):
    total = 0
    for i in range(n):
        if i % 3 == 0:
            continue
        elif i % 3 == 1:
            total = total + i
        else:
            total = total - i
    return total
"""
parse, tagspec, make_cond = pipeline.python_frontend()
body = parse(SRC)
cfg = CFGBuilder(tagspec).build(body)
kinds = sorted({e.kind for e in cfg.edges})
assert "back" in kinds and "then" in kinds and "else" in kinds, kinds
paths = PathEnumerator(cfg, unroll=1).enumerate()
print(f"blocks={len(cfg.blocks)} paths={len(paths)} kinds={kinds}")
assert len(paths) >= 3, paths
print("M21 CERTIFICATE: elif chain + continue ->", len(paths), "paths,",
      sum(1 for e in cfg.edges if e.kind == "back"), "back edges")
