#!/usr/bin/env python
"""M24 -- MIR coverage: constraint-aware gaps at compiler-IR fidelity
(synthetic overlay; cargo llvm-cov slots into the same LCOV parser)."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.paths import PathEnumerator
from pegrex.coverage import covered_lines, parse_lcov, coverage_gaps

MIR = """fn fact(_1: i32) -> i32 {
    let mut _0: i32;
    bb0: {
        switchInt(_1) -> [0: bb1, otherwise: bb2];
    }
    bb1: {
        _0 = const 1_i32;
        goto -> bb2;
    }
    bb2: {
        _0 = _1;
        return;
    }
}
"""
_, cfg_from_mir, _ = pipeline.mir_frontend()
cfg = cfg_from_mir(MIR)
# synthetic LCOV: only bb1 (base case) covered; MIR lines are 1-based
LCOV = "SF:fact.mir\nDA:5,1\nDA:6,1\nDA:8,0\nend_of_record\n"
cov_lines = covered_lines(list(parse_lcov(LCOV).values())[0])

from pegrex.sym import V, const, Eq
cond = lambda node: Eq(V("_1"), const(0))
gaps = coverage_gaps(cfg, cond, cov_lines)
print("MIR paths:", len(PathEnumerator(cfg, unroll=1).enumerate()),
      "| gaps:", len(gaps))
assert any("not" in c for g in gaps for c in g["constraints"])
print("M24 CERTIFICATE: MIR coverage gap carries its constraint")
