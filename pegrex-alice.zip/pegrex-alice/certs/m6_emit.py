#!/usr/bin/env python
"""M6 -- full translation loop with behavioral verification.

Lua fact -> guard-checked idiom rewrite -> complete C source -> gcc ->
run both the translated artifact and the reference C, compare outputs.
The translation is verified at runtime, not just by formula equality.
"""
import pathlib, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline

ROOT = pathlib.Path(__file__).parent.parent

results = pipeline.run_spec("specs/fact.json")
rewrite = results["artifacts"]["if-return-else-return -> ternary"]

artifact = ROOT / "specs" / "fact_ternary.c"
artifact.write_text(f"""int fact(int n) {{
  {rewrite}
}}
#include <stdio.h>
int main(void) {{ printf("%d\\n", fact(5)); return 0; }}
""")
print(f"emitted {artifact}")

harness = ROOT / "specs" / "_ref_main.c"
harness.write_text("""#include <stdio.h>
int fact(int n);
int main(void) { printf("%d\\n", fact(5)); return 0; }
""")

def compile_and_run(objs, exe):
    r = subprocess.run(["gcc"] + [str(o) for o in objs] + ["-o", exe],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    r = subprocess.run([exe], capture_output=True, text=True)
    return r.stdout.strip()

out_t = compile_and_run([artifact], "/tmp/fact_ternary")
out_ref = compile_and_run([ROOT / "specs" / "fact.c", harness], "/tmp/fact_ref")
print(f"translated artifact fact(5) = {out_t}")
print(f"reference C       fact(5) = {out_ref}")
assert out_t == out_ref == "120", (out_t, out_ref)
print()
print("M6 CERTIFICATE: translated artifact behaves identically at runtime")
