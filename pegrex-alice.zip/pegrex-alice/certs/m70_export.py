#!/usr/bin/env python
"""M70 -- export: JSON / CSV / HTML from one findings list."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.export import export

FINDINGS = [{"severity": "HIGH", "id": "x-rule", "line": 3,
             "evidence": "os.system(cmd)"}]
assert '"x-rule"' in export(FINDINGS, "json")
csv_out = export(FINDINGS, "csv")
assert "x-rule" in csv_out and "severity" in csv_out.splitlines()[0]
html_out = export(FINDINGS, "html", title="demo")
assert "<table>" in html_out and "x-rule" in html_out
print("M70 CERTIFICATE: three formats from one list")
