#!/usr/bin/env python
"""M61_OWNERSHIP -- see title."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.ownership import borrow_check
v = borrow_check("let a = &mut x;\nlet b = &mut x;\nlet c = &y;")
print("violations:", v)
assert ("x", "multiple-mut") in v
print("M61 CERTIFICATE: aliasing &mut borrow flagged")
