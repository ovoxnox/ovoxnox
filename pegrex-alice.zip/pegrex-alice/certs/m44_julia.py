#!/usr/bin/env python
"""M44 -- Julia: Newton iteration convergence as a path constraint."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator
import re

SRC = """function newton(f, fp, x0)
    x = x0
    while abs(f(x)) > 1e-8
        x = x - f(x) / fp(x)
    end
    return x
end"""
parse, tags, mk = pipeline.julia_frontend()
cfg = CFGBuilder(tags).build(parse(SRC))
paths = PathEnumerator(cfg, unroll=1).enumerate()
kinds = sorted({e.kind for e in cfg.edges})
assert "back" in kinds and "exit" in kinds
# the loop-exit condition IS the convergence certificate
whl = next(b for b in cfg.blocks if b.term == "loopcond")
from pegrex.tree_sitter_bridge import ts_to_pegrex
import tree_sitter_julia
from tree_sitter import Language, Parser
t = Parser(Language(tree_sitter_julia.language())).parse(SRC.encode())
tree = ts_to_pegrex(t.root_node, SRC)
cond_txt = None
def find_cond(x):
    global cond_txt
    if hasattr(x, "tag"):
        if x.tag == "binary_expression" and cond_txt is None:
            cond_txt = SRC[x.pos:x.endpos]
        for c in x.children: find_cond(c)
find_cond(tree)
print("convergence guard:", cond_txt)
assert "1e-8" in cond_txt
print("M44 CERTIFICATE: Julia Newton convergence guard extracted")
