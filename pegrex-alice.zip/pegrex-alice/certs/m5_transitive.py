#!/usr/bin/env python
"""M5 -- transitive composition: whole-program contracts through a
three-function call chain, compared across languages.

  clamp(x)   = x < 0 and 0 or x
  clamp1(y)  = clamp(y) + 1        (nested: clamp1 -> clamp)
  f(n)       = clamp1(n) * 2       (nested: f -> clamp1 -> clamp)

The fully expanded contract of f must be identical in Lua and C.
"""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pegrex
import pipeline
from pegrex.peg import Node
from pegrex.cfg import CFGBuilder
from pegrex.summaries import render_lua, render_c, path_summaries, expand_calls

ROOT = pathlib.Path(__file__).parent.parent

C_SRC = """int clamp(int x) {
  if (x < 0) { return 0; } else { return x; }
}
int clamp1(int y) {
  return clamp(y) + 1;
}
int f(int n) {
  return clamp1(n) * 2;
}
"""
PY_SRC = """def clamp(x):
    if x < 0:
        return 0
    return x

def clamp1(y):
    return clamp(y) + 1

def f(n):
    return clamp1(n) * 2
"""


def find_all(x, tag, acc):
    if isinstance(x, Node):
        if x.tag == tag:
            acc.append(x)
        for c in x.children:
            find_all(c, tag, acc)
    elif isinstance(x, list):
        for c in x:
            find_all(c, tag, acc)
    return acc


# ---- Python
_parse, tagspec, make_cond = pipeline.python_frontend()


def ts_render(st, src=PY_SRC):
    t = st.children[0] if st.children and isinstance(st.children[0], str) \
        else src[st.pos:st.endpos]
    return t.replace("return", "").strip()


bodies = pipeline.python_functions(PY_SRC)
cl = {nm: path_summaries(CFGBuilder(tagspec).build(b), make_cond(PY_SRC),
                         ts_render) for nm, b in bodies.items()}


# ---- C
parse_c, tagspec_c, make_cond_c = pipeline.c_frontend()
cast = pipeline.c_parse_full(C_SRC)
assert cast is not None
comps = find_all(cast, "compound-statement", [])
cbodies = {"clamp": comps[0], "clamp1": comps[3], "f": comps[-1]}
cc = {nm: path_summaries(CFGBuilder(tagspec_c).build(b), make_cond_c(C_SRC),
                         lambda st: render_c(st, C_SRC))
      for nm, b in cbodies.items()}

params = {"clamp": "x", "clamp1": "y"}
for nm in ("clamp", "clamp1", "f"):
    assert cl[nm] == cc[nm], f"raw contract mismatch: {nm}"

# transitive expansion (bottom-up: clamp -> clamp1 -> f)
def expand_all(c):
    c1 = expand_calls(c["clamp1"], {"clamp": c["clamp"]}, params)
    full = expand_calls(c["f"], {"clamp": c["clamp"], "clamp1": c1}, params)
    return full

full_lua = expand_all(cl)
full_c = expand_all(cc)
print("whole-program contract of f (lua):")
for cons, res in full_lua:
    print(f"  {sorted(cons)} -> {res}")
print("whole-program contract of f (c):")
for cons, res in full_c:
    print(f"  {sorted(cons)} -> {res}")
assert full_lua == full_c
print()
print("M5 CERTIFICATE: transitive whole-program composition identical")
