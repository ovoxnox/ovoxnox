#!/usr/bin/env python
"""M57 -- model checking: invariant over the policy-IR state machine."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.modelcheck import check_invariant

ok = check_invariant([["(n >= 0)"], ["(n >= 0)"]], "(n >= 0)")
assert ok["holds"]
bad = check_invariant([["(n >= 0)"], ["(n < 0)"]], "(n >= 0)")
assert not bad["holds"] and bad["counterexample"]["transition"] == 1
print("M57 CERTIFICATE: invariant holds / counterexample found")
