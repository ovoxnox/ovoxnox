#!/usr/bin/env python
"""M41 -- three-valued taint: unknown sources reported, never silently clean."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.taint import analyze_taint
from pegrex.tree_sitter_bridge import ts_to_pegrex
from pegrex.peg import Node
import tree_sitter_python
from tree_sitter import Language, Parser

SRC = """import os
def run(user_cfg):
    cfg = load_config(user_cfg)   # unknown: not a known source, not clean
    os.system(cfg)                # strict -> UNKNOWN report (not silent)
def ok():
    os.system("ls")               # literal -> clean
"""
root = Parser(Language(tree_sitter_python.language())).parse(SRC.encode()).root_node
tree = ts_to_pegrex(root, SRC)
rule = {"sinks": [r"\bsystem\s*\("], "sources": [r"request"],
        "sanitizers": [], "strict_missing": True}
findings, unknowns = analyze_taint(tree, SRC, rule)
print("findings:", findings)
print("unknowns:", unknowns)
assert not findings
assert len(unknowns) == 1 and "cfg" in unknowns[0]["evidence"]
print("M41 CERTIFICATE: unknown taint reported, literal clean")
