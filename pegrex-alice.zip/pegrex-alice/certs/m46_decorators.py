#!/usr/bin/env python
"""M46 -- decorators: @functools.cache reclassifies unbounded recursion."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.recursion import analyze_recursion
from pegrex.peg import Node

SRC_CACHED = """from functools import cache

@cache
def fib(n):
    return fib(n - 1) + fib(n - 2)
"""
SRC_RAW = """def fib(n):
    return fib(n - 1) + fib(n - 2)
"""

def decorators_of(src):
    """decorator names from the raw tree (parse() bodies drop them)."""
    import tree_sitter_python
    from tree_sitter import Language, Parser
    from pegrex.tree_sitter_bridge import ts_to_pegrex
    tree = ts_to_pegrex(Parser(Language(tree_sitter_python.language()))
                        .parse(src.encode()).root_node, src)
    names = []
    def walk(n):
        if isinstance(n, Node):
            if n.tag == "decorator":
                txt = src[n.pos:n.endpos]
                names.append(txt.replace("@", "").split("(")[0].strip())
            for c in n.children:
                walk(c)
        elif isinstance(n, list):
            for c in n:
                walk(c)
    walk(tree)
    return names

parse, tags, mk = pipeline.python_frontend()
for label, src in (("cached", SRC_CACHED), ("raw", SRC_RAW)):
    body = parse(src)
    decs = decorators_of(src)
    report = analyze_recursion("fib", body, src)
    memoized = any("cache" in d or "lru_cache" in d for d in decs)
    print(f"{label}: decorators={decs} unbounded={report.unbounded} "
          f"memoized={memoized}")
    if memoized:
        print(f"   -> reclassified: unbounded-by-structure, bounded-by-cache")
assert decorators_of(SRC_CACHED) == ["cache"]
print("M46 CERTIFICATE: @cache reclassifies recursion (structure vs memoization)")
