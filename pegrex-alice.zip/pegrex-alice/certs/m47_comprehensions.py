#!/usr/bin/env python
"""M47 -- comprehensions: generator expressions as implicit loops."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pegrex  # vendors bindings
import tree_sitter_python
from tree_sitter import Language, Parser
from pegrex.tree_sitter_bridge import ts_to_pegrex
from pegrex.peg import Node

SRC = """def sums(n):
    squares = [i * i for i in range(n)]
    total = sum(x for x in squares)
    return total
"""
tree = ts_to_pegrex(Parser(Language(tree_sitter_python.language()))
                    .parse(SRC.encode()).root_node, SRC)

comps = []
def walk(n):
    if isinstance(n, Node):
        if n.tag == "list_comprehension" and n not in comps:
            comps.append(n)
        if n.tag == "generator_expression" and n not in comps:
            comps.append(n)
        for c in n.children:
            walk(c)
    elif isinstance(n, list):
        for c in n:
            walk(c)
walk(tree)
print(f"comprehensions: {len(comps)}")
for c in comps:
    txt = SRC[c.pos:c.endpos].strip()
    print(f"  {c.tag}: {txt[:50]}")

# each comprehension has a for_clause = an implicit loop
loops = 0
def find_for(x):
    global loops
    if isinstance(x, Node):
        if x.tag in ("for_clause", "for_in_clause"):
            loops += 1
        for c in x.children:
            find_for(c)
    elif isinstance(x, list):
        for c in x:
            find_for(c)
find_for(tree)
print(f"for_clauses (implicit loops): {loops}")
assert len(comps) == 2 and loops == 2
print("M47 CERTIFICATE: comprehensions = 2 implicit loops, both recognized")
