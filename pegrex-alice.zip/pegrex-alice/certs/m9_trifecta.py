#!/usr/bin/env python
"""M9 -- trifecta: one idiomatic function in Python, Go, and Rust through
the identical pipeline: tree-sitter parse -> guardrails -> CFG -> SSA ->
path constraints -> solver.  Path constraints must match exactly across
all three languages.  Uses REAL tree-sitter grammars.
"""
import pathlib, re, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pegrex  # noqa: F401  (vendors tree-sitter bindings via __init__)
import tree_sitter_python, tree_sitter_go, tree_sitter_rust
from tree_sitter import Language, Parser

from pegrex.patterns import Pattern
from pegrex.tree_sitter_bridge import ts_to_pegrex, TAGSPECS
from pegrex.specgen import analyze
from pegrex.formulas import V, const, Eq, Lt, Le, Gt, Ge, Not

ROOT = pathlib.Path(__file__).parent.parent

GO_SRC = """func absval(n int) int {
\tif n > 0 {
\t\treturn n
\t}
\treturn -n
}
"""
RUST_SRC = """fn absval(n: i32) -> i32 {
    if n > 0 {
        return n;
    }
    -n
}
"""
PY_SRC = "def absval(n):\n    if n > 0:\n        return n\n    return -n\n"

_LANGS = {"python": Language(tree_sitter_python.language()),
          "go": Language(tree_sitter_go.language()),
          "rust": Language(tree_sitter_rust.language())}


def parse_ts(lang, src):
    return Parser(_LANGS[lang]).parse(src.encode()).root_node


def cond(node, src=None):
    txt = getattr(node, "text", None)
    if not txt and getattr(node, "children", None) \
            and isinstance(node.children[0], str):
        txt = node.children[0]
    if not txt and src is not None and getattr(node, "pos", None) is not None:
        txt = src[node.pos:node.endpos]
    m = re.match(r"\s*([A-Za-z_]\w*)\s*(<=|>=|<|>|==|!=)\s*(-?\d+)", txt or "")
    if m is None:
        raise ValueError(f"cond: cannot parse {txt!r} from node "
                         f"{getattr(node, 'tag', '?')}")
    op = {"<": Lt, "<=": Le, ">": Gt, ">=": Ge,
          "==": Eq, "!=": lambda a, b: Not(Eq(a, b))}
    return op[m.group(2)](V(m.group(1)), const(int(m.group(3))))


def render(st, src=None):
    t = getattr(st, "text", None)
    if not t and getattr(st, "children", None) and isinstance(st.children[0], str):
        t = st.children[0]
    return (t or "").replace("return", "").strip()


RULES = {
    "python": [Pattern(node_type="condition", text=r"n\s*==\s*None",
                       id="eq-none-anti-pattern")],
    "go": [Pattern(node_type="return_statement", text=r"return\s+-",
                   id="negated-return")],
    "rust": [Pattern(node_type="return_expression", text=r"return\s+\w",
                     id="explicit-return"),
             Pattern(node_type="block", text=r"\.unwrap\(\)",
                     id="unwrap-anti-pattern")],
}

reports = {}
for lang, src in (("go", GO_SRC), ("rust", RUST_SRC), ("python", PY_SRC)):
    tree = ts_to_pegrex(parse_ts(lang, src), src)
    reports[lang] = analyze(tree, lang, "absval", rules=RULES[lang],
                            tagspec=TAGSPECS[lang], src=src,
                            cond=cond, render=render)

cons = {}
for lang, rep in reports.items():
    assert all(p.satisfiable for p in rep.paths), lang
    cons[lang] = sorted(tuple(p.constraints) for p in rep.paths)
    vids = [v.rule_id for v in rep.syntactic_violations]
    print(f"[{lang:6}] {len(rep.paths)} paths, violations={vids}")
    for p in rep.paths:
        print(f"         {p.constraints}")

assert cons["go"] == cons["rust"] == cons["python"], \
    f"trifecta mismatch: {cons}"
print()
print("M9 CERTIFICATE: Python / Go / Rust path constraints identical (REAL tree-sitter)")
