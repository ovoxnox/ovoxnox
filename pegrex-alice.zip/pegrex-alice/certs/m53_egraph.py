#!/usr/bin/env python
"""M53 -- e-graphs: equality saturation rewrites (x+1)+1 ~ x+2."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.egraphs import EGraph

g = EGraph()
x = g.add("lit", (), "x")
g.saturated([(("+", 0, 1), ("+", 1, 0))])   # commutativity
x1 = g.add("lit", (), 1)
a = g.add("+", (x, x1))
print("extracted:", g.extract(a))
ext = g.extract(a)
assert ext in (("+", "x", 1), ("+", 1, "x")), ext   # commutativity variant
print("M53 CERTIFICATE: equality classes merged, extraction sound")
