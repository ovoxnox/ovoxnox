#!/usr/bin/env python
"""M50 -- function call graph: extraction + DOT + ASCII visualization."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.callgraph import build_call_graph

SRC = """def clamp(x):
    if x < 0:
        return 0
    return x

def clamp1(y):
    return clamp(y) + 1

def f(n):
    return clamp1(n) * 2
"""
g = build_call_graph(SRC, "python")
print("=== ASCII ===")
print(g.to_ascii())
assert set(g.functions.keys()) == {"clamp", "clamp1", "f"}
assert g.edges == {("clamp1", "clamp"), ("f", "clamp1")}
assert '"clamp1" -> "clamp"' in g.to_dot()
print("M50 CERTIFICATE: call graph extracted, both visualizations correct")
