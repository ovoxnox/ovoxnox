#!/usr/bin/env python
"""M27 -- generators + yield: suspend-points as ordinary statements."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator

PY = """def squares(n):
    for i in range(n):
        if i % 2 == 0:
            yield i * i
        else:
            yield -i
    return 0
"""
parse, tagspec, make_cond = pipeline.python_frontend()
body = parse(PY)
cfg = CFGBuilder(tagspec).build(body)
kinds = sorted({e.kind for e in cfg.edges})
yields = sum(1 for b in cfg.blocks for s in b.stmts
             if getattr(s, "tag", "") == "yield")
paths = PathEnumerator(cfg, unroll=1).enumerate()
print(f"edges: {kinds} | yield stmts: {yields} | paths: {len(paths)}")
assert "back" in kinds and yields == 2 and len(paths) >= 2
print("M27 CERTIFICATE: generator with yields ->", len(paths), "paths")
