#!/usr/bin/env python
"""M60 -- circuits: gate netlists checked for consistency."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.circuit import check_circuit

ok = check_circuit(["(n = 3)", "(m = 5)"])
assert ok["consistent"]
print("M60 CERTIFICATE: circuit equations consistent under the SMT core")
