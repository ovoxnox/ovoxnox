#!/usr/bin/env python
"""M13 -- nested control flow: loop-in-condition, break, compound guards."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator

SRC = """def search(grid, target):
    found = False
    for row in grid:
        for cell in row:
            if cell == target and not found:
                found = True
                break
        if found:
            break
    return found
"""
parse, tagspec, make_cond = pipeline.python_frontend()
body = parse(SRC)
cfg = CFGBuilder(tagspec).build(body)
paths = PathEnumerator(cfg, unroll=1).enumerate()
kinds = {(e.kind) for e in cfg.edges}
print(f"blocks={len(cfg.blocks)} paths={len(paths)} edge_kinds={sorted(kinds)}")
assert "back" in kinds and "body" in kinds
assert len(paths) >= 2
print("M13 CERTIFICATE: nested loops + break + compound guard ->",
      len(paths), "paths at unroll=1")
