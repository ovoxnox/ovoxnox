#!/usr/bin/env python
"""M33 -- OpenMP/PyOMP: pragma recognition + data-race heuristic."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from pegrex.parallel import race_findings, find_pragmas

C_SRC = """#include <omp.h>
int main() {
    int counter = 0;
    #pragma omp parallel for
    for (int i = 0; i < 100; i++) {
        counter += 1;   // race: shared write, no critical/atomic
    }
    return counter;
}
"""
PY_SRC = """import pyomp
counter = 0
#$ omp parallel for
for i in range(100):
    counter += 1   # race: shared write, no sync
"""

c_regions = find_pragmas(C_SRC)
c_races = race_findings(C_SRC)
py_regions = find_pragmas(PY_SRC)
py_races = race_findings(PY_SRC)
print(f"C: {len(c_regions)} pragma(s), races: {c_races}")
print(f"PyOMP: {len(py_regions)} pragma(s), races: {py_races}")
assert c_races and py_races
# safe version: atomic -> no race
SAFE = C_SRC.replace("counter += 1;", "#pragma omp atomic\n        counter += 1;")
assert not race_findings(SAFE)
print("M33 CERTIFICATE: OpenMP + PyOMP pragmas, race detected, atomic suppresses")
