#!/usr/bin/env python
"""M65_POC -- see title."""
import pathlib, sys, tempfile
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.poc import poc_template, codegen_gate
print(poc_template({"id": "cmd-injection", "line": 7,
                    "evidence": "os.system(cmd)"}).splitlines()[0])
gate = codegen_gate("import os\ndef f(c):\n    os.system(c)\n")
print("codegen gate accepted:", gate["accepted"], "| findings:", len(gate["findings"]))
assert not gate["accepted"] and gate["findings"]
print("M65 CERTIFICATE: PoC templated, codegen blocked pre-editor")
