#!/usr/bin/env python
"""M10 -- complex code through the real tree-sitter frontend.

A realistic function: local state, a while loop with a compound-free
condition, assignments in the body.  Verifies: back edges + bounded
enumeration, closed-form loop summary, and SSA versions on a real AST.
"""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
import pegrex
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator
from pegrex.summaries import path_summaries
from pegrex.loops import detect, contract_closed_form
from pegrex.assign import numeric_inits, loop_assignments

PY_SUM = """def sum_to(n):
    s = 0
    i = 1
    while i <= n:
        s = s + i
        i = i + 1
    return s
"""

parse, tagspec, make_cond = pipeline.python_frontend()
tree_src = PY_SUM
import tree_sitter_python
from tree_sitter import Language, Parser
from pegrex.tree_sitter_bridge import ts_to_pegrex
root = Parser(Language(tree_sitter_python.language())).parse(PY_SUM.encode()).root_node
tree = ts_to_pegrex(root, PY_SUM)
body = pipeline._first_function(tree, "python")
cfg = CFGBuilder(tagspec).build(body)
print("CFG:", len(cfg.blocks), "blocks,", len(cfg.edges), "edges")
print(cfg.to_dot())
print()

# 1) bounded path enumeration (unroll=1)
paths = PathEnumerator(cfg, unroll=1).enumerate()
print(f"paths (unroll=1): {len(paths)}")
for p in paths:
    print("  ", p)
print()

# 2) path constraints per path
cond = make_cond(PY_SUM)
cons = []
for p in paths:
    cs = []
    for i in range(len(p) - 1):
        for dst, e in cfg.successors(p[i]):
            if dst != p[i + 1] or e.cond is None:
                continue
            if e.kind in ("then", "body"):
                cs.append(str(cond(e.cond)))
            elif e.kind in ("else", "exit"):
                from pegrex.sym import Not
                base = e.cond[0] if isinstance(e.cond, tuple) else e.cond
                cs.append(str(Not(cond(base))))
    cons.append(frozenset(cs))
    print(f"  path {p}: {sorted(cs)}")
print()

# 3) closed-form loop summary
whl = None
def findw(x):
    global whl
    if hasattr(x, "tag"):
        if x.tag == "while_statement" and whl is None:
            whl = x
        for c in x.children:
            findw(c)
findw(body)
assigns = loop_assignments(whl, PY_SUM)
inits = numeric_inits(tree, PY_SUM)
print("loop body:", assigns, "| inits:", inits)
lp = detect(assigns, inits)
assert lp is not None
cf = contract_closed_form(lp, "n")
print("closed form:", cf)
assert cf["result"] == "(n * (n + 1))"
print()
print("M10 CERTIFICATE: complex code (state + loop + assignments) fully analyzed")
