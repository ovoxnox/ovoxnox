#!/usr/bin/env python
"""M48 -- Zig: if/else paths through the CFG."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator

parse, tags, mk = pipeline.zig_frontend()
cfg = CFGBuilder(tags).build(parse(
    "fn classify(n: i32) i32 {\n    if (n > 0) {\n        return 1;\n    } else {\n        return 0;\n    }\n}"))
paths = PathEnumerator(cfg, unroll=1).enumerate()
kinds = sorted({e.kind for e in cfg.edges})
print(f"zig: {len(paths)} paths, edges={kinds}")
assert len(paths) == 2 and "then" in kinds and "else" in kinds
print("M48 CERTIFICATE: Zig if/else -> 2 paths")
