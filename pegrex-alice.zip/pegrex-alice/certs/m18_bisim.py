#!/usr/bin/env python
"""M18 -- bisimulation certificate: Python and C fact() are equivalent
without path enumeration bounds (label-multiset bisimulation)."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.bisim import bisimilar
from pegrex.summaries import render_c
import pathlib as pl

py_src = pl.Path("specs/fact.py").read_text()
c_src = pl.Path("specs/fact.c").read_text()
p_parse, p_tags, p_cond = pipeline.python_frontend()
c_parse, c_tags, c_cond = pipeline.c_frontend()
py_cfg = CFGBuilder(p_tags).build(p_parse(py_src))
c_cfg = CFGBuilder(c_tags).build(c_parse(c_src))
p_render = lambda st: (py_src[st.pos:st.endpos]).replace("return", "").strip()
c_render = lambda st: render_c(st, c_src)

assert bisimilar(py_cfg, c_cfg, p_cond(py_src), c_cond(c_src), p_render, c_render)
print("M18 CERTIFICATE: Python and C fact() bisimilar (bound-free equivalence)")
