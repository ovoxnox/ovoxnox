#!/usr/bin/env python
"""M42 -- Solidity: withdraw-path constraints + security rule pack."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator

SRC = """contract Vault {
  function withdraw(uint amount) public returns (bool) {
    if (amount <= balances[msg.sender]) {
      return true;
    }
    return false;
  }
}"""
parse, tags, mk = pipeline.solidity_frontend()
cfg = CFGBuilder(tags).build(parse(SRC))
paths = PathEnumerator(cfg, unroll=1).enumerate()
print(f"solidity withdraw: {len(paths)} paths")
assert len(paths) == 2

pathlib.Path("/tmp/vuln.sol").write_text("""contract W {
  function pay() public {
    require(tx.origin == owner);
    msg.sender.call.value(1 ether)("");
    selfdestruct(owner);
  }
}""")
import subprocess as sp
r = sp.run([sys.executable, "tools/secaudit.py", "/tmp/vuln.sol"],
           cwd="/mnt/agents/output", capture_output=True, text=True)
hits = [l for l in r.stdout.splitlines() if l.startswith(("CRITICAL", "HIGH", "MEDIUM"))]
print("rule pack hits:", len(hits))
for l in hits[:4]: print("  ", l[:85])
assert any("tx.origin" in l for l in hits)
print("M42 CERTIFICATE: Solidity paths + security rules")
