#!/usr/bin/env python
"""M54 -- proof repair: AST diff isolates changed regions."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
import pipeline
from pegrex.proofrepair import ast_fingerprint, diff_blocks

SRC1 = "def f(n):\n    if n > 0:\n        return 1\n    return 0\n"
SRC2 = "def f(n):\n    if n > 10:\n        return 1\n    return 0\n"
t1 = pipeline.python_frontend()[0](SRC1)
t2 = pipeline.python_frontend()[0](SRC2)
changed = diff_blocks(t1, t2)
print("changed subtrees:", len(changed))
assert changed, "the constant edit must surface as a fingerprint diff"
print("M54 CERTIFICATE: incremental diff isolates the repair region")
