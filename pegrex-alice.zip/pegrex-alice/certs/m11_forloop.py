#!/usr/bin/env python
"""M11 -- for loops: counting-loop certificate via the new for_ dispatch."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder
from pegrex.paths import PathEnumerator

SRC = """def total(n):
    s = 0
    for i in range(n):
        s = s + i
    return s
"""
parse, tagspec, make_cond = pipeline.python_frontend()
body = parse(SRC)
cfg = CFGBuilder(tagspec).build(body)
paths = PathEnumerator(cfg, unroll=1).enumerate()
assert len(paths) == 2, paths
cons = set()
for p in paths:
    for i in range(len(p) - 1):
        for dst, e in cfg.successors(p[i]):
            if dst == p[i + 1] and e.kind in ("body", "exit"):
                cons.add(e.kind)
assert cons == {"body", "exit"}, cons
print("M11 CERTIFICATE: for-loop back edge + exit edge, 2 paths (unroll=1)")
