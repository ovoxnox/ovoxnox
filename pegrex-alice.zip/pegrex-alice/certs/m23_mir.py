#!/usr/bin/env python
"""M23 -- MIR frontend: rustc's IR dump -> CFG -> paths (compiler-IR fidelity)."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.paths import PathEnumerator

MIR = """fn fact(_1: i32) -> i32 {
    let mut _0: i32;
    bb0: {
        switchInt(_1) -> [0: bb1, otherwise: bb2];
    }
    bb1: {
        _0 = const 1_i32;
        goto -> bb2;
    }
    bb2: {
        _0 = _1;
        return;
    }
}
"""
_, cfg_from_mir, _ = pipeline.mir_frontend()
cfg = cfg_from_mir(MIR)
paths = PathEnumerator(cfg, unroll=1).enumerate()
print("blocks:", len(cfg.blocks), "paths:", len(paths))
assert len(paths) == 2, paths
print("M23 CERTIFICATE: MIR dump -> CFG -> 2 paths")
