#!/usr/bin/env python
"""M19 -- repo index + verification bundle artifacts."""
import pathlib, sys, json
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

from tools.repokit import repo_index, verification_bundle

idx = repo_index("specs", out="/tmp/repo.index.json")
print(f"repo index: {len(idx['containers'])} containers")
assert idx["containers"] and idx["containers"][0]["depends_on"] is not None

bundle = verification_bundle("specs/fact.py", out="/tmp/fact.bundle.json")
assert len(bundle["paths"]) == 2
assert "assert" in bundle["smt2"] and "declare-fun" in bundle["smt2"]
print(f"bundle: {len(bundle['paths'])} paths, sha {bundle['source_sha256'][:12]}")
print("M19 CERTIFICATE: repo index + portable verification bundle emitted")
