#!/usr/bin/env python
"""M35 -- context managers: enter/exit/exceptional-exit paths."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))

import pipeline
from pegrex.cfg import CFGBuilder

SRC = """def read_config(path):
    with open(path) as f:
        return f.read()
"""
parse, tagspec, make_cond = pipeline.python_frontend()
body = parse(SRC)
cfg = CFGBuilder(tagspec).build(body)
kinds = sorted({e.kind for e in cfg.edges})
print("edge kinds:", kinds)
assert "enter" in kinds and "exit" in kinds and "raise" in kinds, kinds
print("M35 CERTIFICATE: with-statement -> enter/exit/exceptional-exit")
