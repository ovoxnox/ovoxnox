#!/usr/bin/env python
"""M63_TRANSPILER -- see title."""
import pathlib, sys, tempfile, json
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from pegrex.transpiler import transpile
src = tempfile.NamedTemporaryFile("w", suffix=".py", delete=False)
src.write("def f(n):\n    if n > 0:\n        return 1\n    return 0\n")
src.close()
b = transpile(src.name, "javascript", tempfile.mktemp(suffix=".json"))
assert len(b["paths"]) == 2 and b["target_lang"] == "javascript"
print("M63 CERTIFICATE: transpile bundle emitted with paths + proof slot")
