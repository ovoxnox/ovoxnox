import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent


def test_chain_spec_whole_program_certificate():
    r = subprocess.run([sys.executable, "pipeline.py", "specs/chain.json"],
                       cwd=ROOT, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    assert "certificate issued" in r.stdout
    assert "(n < 0)" in r.stdout and "(0 + 1) * 2" in r.stdout
